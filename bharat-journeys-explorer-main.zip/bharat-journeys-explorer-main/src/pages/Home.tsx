import { useState } from 'react';
import { motion } from 'framer-motion';
import SplashScreen from '@/components/SplashScreen';
import InteractiveMap from '@/components/InteractiveMap';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const Home = () => {
  const [showSplash, setShowSplash] = useState(true);

  const handleSplashComplete = () => {
    setShowSplash(false);
  };

  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto px-4 py-16 text-center"
      >
        <div className="max-w-4xl mx-auto space-y-6">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent"
          >
            Interactive Heritage Map of India
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto leading-relaxed"
          >
            Discover the rich tapestry of India's cultural heritage through an immersive interactive experience. 
            Hover over states to explore their unique traditions, click to dive deep into their history, festivals, and monuments.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex flex-wrap justify-center gap-3 pt-4"
          >
            <Badge variant="heritage" className="text-sm px-4 py-2">
              🏛️ Historic Monuments
            </Badge>
            <Badge variant="cultural" className="text-sm px-4 py-2">
              🎭 Traditional Arts
            </Badge>
            <Badge variant="mystic" className="text-sm px-4 py-2">
              🎪 Vibrant Festivals
            </Badge>
            <Badge variant="heritage" className="text-sm px-4 py-2">
              🍛 Rich Cuisine
            </Badge>
          </motion.div>
        </div>
      </motion.section>

      {/* Interactive Map Section */}
      <motion.section 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 1 }}
        className="container mx-auto px-4 pb-16"
      >
        <Card className="heritage-shadow">
          <CardContent className="p-6">
            <InteractiveMap />
          </CardContent>
        </Card>
      </motion.section>

      {/* Features Section */}
      <motion.section 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.8 }}
        className="container mx-auto px-4 pb-16"
      >
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent mb-4">
            Explore India's Cultural Diversity
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Each state tells a unique story of traditions, history, and heritage that has shaped India's cultural landscape.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.6 }}
          >
            <Card className="text-center heritage-shadow hover:scale-105 smooth-transition">
              <CardContent className="p-8">
                <div className="text-4xl mb-4">🗺️</div>
                <h3 className="text-xl font-semibold mb-3 text-foreground">Interactive Exploration</h3>
                <p className="text-foreground/70">
                  Hover and click on any state to discover its unique cultural heritage, monuments, and traditions.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.4, duration: 0.6 }}
          >
            <Card className="text-center heritage-shadow hover:scale-105 smooth-transition">
              <CardContent className="p-8">
                <div className="text-4xl mb-4">📚</div>
                <h3 className="text-xl font-semibold mb-3 text-foreground">Rich Content</h3>
                <p className="text-foreground/70">
                  Detailed information about history, festivals, monuments, and cultural highlights of each state.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.6, duration: 0.6 }}
          >
            <Card className="text-center heritage-shadow hover:scale-105 smooth-transition">
              <CardContent className="p-8">
                <div className="text-4xl mb-4">🎨</div>
                <h3 className="text-xl font-semibold mb-3 text-foreground">Visual Journey</h3>
                <p className="text-foreground/70">
                  Beautiful imagery and descriptions that bring India's cultural diversity to life.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.section>
    </div>
  );
};

export default Home;