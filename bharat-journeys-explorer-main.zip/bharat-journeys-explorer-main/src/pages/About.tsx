import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto px-4 py-16 text-center"
      >
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent mb-6"
        >
          About Bharat Darpan
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="text-xl text-foreground/80 max-w-3xl mx-auto"
        >
          A digital mirror reflecting India's rich cultural heritage, traditions, and the timeless beauty of our diverse nation.
        </motion.p>
      </motion.section>

      <div className="container mx-auto px-4 pb-16 space-y-12">
        {/* Mission Section */}
        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <Card className="heritage-shadow">
            <CardHeader>
              <CardTitle className="text-3xl text-center bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Our Mission
              </CardTitle>
            </CardHeader>
            <CardContent className="text-lg leading-relaxed text-foreground/90 space-y-4">
              <p>
                Bharat Darpan (भारत दर्पण) serves as a digital gateway to India's incredible cultural diversity. 
                Our platform aims to preserve, celebrate, and share the rich heritage of each Indian state through 
                an immersive and educational experience.
              </p>
              <p>
                We believe that understanding our cultural roots is essential for appreciating the unity in diversity 
                that makes India unique. Through interactive exploration, detailed historical narratives, and 
                comprehensive cultural information, we strive to connect people with their heritage.
              </p>
            </CardContent>
          </Card>
        </motion.section>

        {/* Features Grid */}
        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
            What We Offer
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Interactive Map",
                description: "Explore India through an intuitive, clickable map that brings each state to life with hover effects and detailed information.",
                icon: "🗺️",
                badge: "Core Feature"
              },
              {
                title: "Rich Historical Content",
                description: "Comprehensive historical narratives that go beyond surface-level information to provide deep insights into each state's past.",
                icon: "📚",
                badge: "Educational"
              },
              {
                title: "Festival Celebrations",
                description: "Detailed information about traditional festivals, their significance, and how they are celebrated across different regions.",
                icon: "🎪",
                badge: "Cultural"
              },
              {
                title: "Monument Directory",
                description: "Curated collection of historic monuments with visiting information, architectural details, and cultural significance.",
                icon: "🏛️",
                badge: "Heritage"
              },
              {
                title: "Cultural Highlights",
                description: "Explore traditional arts, music, dance, cuisine, and customs that define each state's unique cultural identity.",
                icon: "🎨",
                badge: "Traditions"
              },
              {
                title: "Mobile Responsive",
                description: "Seamless experience across all devices, ensuring cultural exploration is accessible anytime, anywhere.",
                icon: "📱",
                badge: "Technology"
              }
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1 + index * 0.1, duration: 0.6 }}
              >
                <Card className="h-full heritage-shadow hover:scale-105 smooth-transition">
                  <CardHeader>
                    <div className="text-4xl mb-2">{feature.icon}</div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                    <Badge variant="cultural" className="w-fit">{feature.badge}</Badge>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground/80">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Vision Section */}
        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.5, duration: 0.8 }}
        >
          <Card className="heritage-shadow">
            <CardHeader>
              <CardTitle className="text-3xl text-center bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
                Our Vision
              </CardTitle>
            </CardHeader>
            <CardContent className="text-lg leading-relaxed text-foreground/90 space-y-4">
              <p>
                We envision a world where India's cultural heritage is accessible to everyone, transcending 
                geographical boundaries and language barriers. Bharat Darpan aims to be the definitive 
                digital repository of Indian culture, inspiring pride in our heritage and fostering 
                cultural understanding among global audiences.
              </p>
              <p>
                Through technology and storytelling, we hope to ensure that future generations remain 
                connected to their roots while embracing modernity. Our platform serves as a bridge 
                between tradition and innovation, preserving cultural wisdom for posterity.
              </p>
            </CardContent>
          </Card>
        </motion.section>

        {/* Values Section */}
        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.7, duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Our Values
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                title: "Cultural Authenticity",
                description: "We are committed to presenting accurate, well-researched information that honors the true essence of each cultural tradition."
              },
              {
                title: "Inclusive Representation",
                description: "Our platform celebrates the diversity of all Indian states and union territories, ensuring every culture is represented with equal respect."
              },
              {
                title: "Educational Excellence",
                description: "We strive to provide content that is both informative and engaging, making learning about Indian culture an enriching experience."
              },
              {
                title: "Technological Innovation",
                description: "We leverage modern technology to create intuitive, accessible experiences that bring cultural heritage to life in the digital age."
              }
            ].map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1.9 + index * 0.1, duration: 0.6 }}
              >
                <Card className="heritage-shadow">
                  <CardHeader>
                    <CardTitle className="text-xl text-primary">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground/80">{value.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>
      </div>
    </div>
  );
};

export default About;