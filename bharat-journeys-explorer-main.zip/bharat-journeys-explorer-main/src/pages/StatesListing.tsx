import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Map, ArrowRight } from 'lucide-react';
import { getAllStates, getStateBySlug } from '@/data/statesDataEnhanced';

const StatesListing = () => {
  const stateNames = getAllStates();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto px-4 py-16 text-center"
      >
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent mb-6"
        >
          Explore All States
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="text-xl text-foreground/80 max-w-2xl mx-auto mb-8"
        >
          Discover the rich cultural heritage, history, and traditions of each Indian state through detailed exploration.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <Button variant="heritage" asChild size="lg" className="gap-2">
            <Link to="/">
              <Map className="w-5 h-5" />
              Back to Interactive Map
            </Link>
          </Button>
        </motion.div>
      </motion.section>

      {/* States Grid */}
      <motion.section 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 1 }}
        className="container mx-auto px-4 pb-16"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stateNames.map((stateName, index) => {
            const stateData = getStateBySlug(stateName);
            if (!stateData) return null;

            return (
              <motion.div
                key={stateName}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 + index * 0.1, duration: 0.6 }}
              >
                <Card className="h-full heritage-shadow hover:scale-105 smooth-transition group">
                  <CardHeader>
                    <CardTitle className="text-2xl bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                      {stateData.name}
                    </CardTitle>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="heritage">
                        {stateData.festivals.length} Festivals
                      </Badge>
                      <Badge variant="cultural">
                        {stateData.monuments.length} Monuments
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-foreground/80 line-clamp-3">
                      {stateData.description}
                    </p>
                    
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm text-foreground/90">Featured Highlights:</h4>
                      <div className="flex flex-wrap gap-1">
                        {stateData.culturalHighlights.slice(0, 3).map((highlight) => (
                          <Badge key={highlight.name} variant="mystic" className="text-xs">
                            {highlight.category}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <Button 
                      variant="ghost" 
                      asChild 
                      className="w-full group-hover:bg-primary/10 group-hover:text-primary"
                    >
                      <Link to={`/state/${stateName}`} className="gap-2">
                        Explore {stateData.name}
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 smooth-transition" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </motion.section>

      {/* Call to Action */}
      <motion.section 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="container mx-auto px-4 pb-16 text-center"
      >
        <Card className="heritage-shadow">
          <CardContent className="p-12">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent mb-4">
              Continue Your Journey
            </h2>
            <p className="text-lg text-foreground/70 mb-8 max-w-2xl mx-auto">
              Return to the interactive map to explore more states and discover the incredible diversity of India's cultural heritage.
            </p>
            <Button variant="heritage" asChild size="lg" className="gap-2">
              <Link to="/">
                <Map className="w-5 h-5" />
                Interactive Heritage Map
              </Link>
            </Button>
          </CardContent>
        </Card>
      </motion.section>
    </div>
  );
};

export default StatesListing;