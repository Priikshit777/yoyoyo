export interface Monument {
  name: string;
  location: string;
  bestSeason: string;
  description: string;
  image?: string;
}

export interface Festival {
  name: string;
  significance: string;
  description: string;
  celebration: string;
  video?: string;
}

export interface CulturalHighlight {
  category: string;
  name: string;
  description: string;
  image?: string;
}

export interface StateData {
  name: string;
  image: string;
  history: string;
  festivals: Festival[];
  monuments: Monument[];
  culturalHighlights: CulturalHighlight[];
  description: string;
}

export const allStatesData: Record<string, StateData> = {
  "andhra-pradesh": {
    name: "Andhra Pradesh",
    image: "/api/placeholder/800/400",
    description: "The rice bowl of India, known for its rich cultural heritage, ancient temples, and spicy cuisine.",
    history: "Andhra Pradesh has a glorious history dating back to the Satavahana dynasty (230 BCE - 220 CE). The region witnessed the rule of great dynasties like the Pallavas, Cholas, Kakatiyas, and Vijayanagara Empire. The state is renowned for its Buddhist heritage, with sites like Amaravati and Nagarjunakonda. The Mughal and British periods significantly influenced the region's culture and architecture. Post-independence, the state played a crucial role in India's linguistic reorganization and later bifurcated to form Telangana in 2014.",
    festivals: [
      {
        name: "Ugadi",
        significance: "New Year celebration marking spring's arrival",
        description: "Telugu New Year celebrated with great enthusiasm across Andhra Pradesh.",
        celebration: "People decorate homes with mango leaves, prepare traditional Ugadi pachadi with six tastes representing life's emotions, and exchange greetings. Special prayers are offered, and astrological predictions for the new year are read."
      },
      {
        name: "Bommala Koluvu",
        significance: "Festival of dolls during Navaratri",
        description: "A unique festival where families display elaborate doll arrangements depicting mythological stories.",
        celebration: "Homes are transformed into galleries with creative doll displays, cultural programs, and traditional music. Visitors go house-to-house admiring the artistic arrangements."
      }
    ],
    monuments: [
      {
        name: "Tirumala Venkateswara Temple",
        location: "Tirupati",
        bestSeason: "October to March",
        description: "One of the richest and most visited temples in the world, dedicated to Lord Venkateswara."
      },
      {
        name: "Belum Caves",
        location: "Kurnool",
        bestSeason: "October to March",
        description: "Second largest cave system in India with stalactite and stalagmite formations."
      },
      {
        name: "Borra Caves",
        location: "Visakhapatnam",
        bestSeason: "October to April",
        description: "Million-year-old limestone caves with stunning natural formations."
      },
      {
        name: "Charminar",
        location: "Hyderabad",
        bestSeason: "October to March",
        description: "Iconic monument built in 1591, symbol of Hyderabad's heritage."
      },
      {
        name: "Golconda Fort",
        location: "Hyderabad",
        bestSeason: "October to March",
        description: "Medieval fort famous for its acoustic system and diamond mines."
      },
      {
        name: "Araku Valley",
        location: "Visakhapatnam",
        bestSeason: "October to March",
        description: "Hill station known for coffee plantations and tribal culture."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Andhra Cuisine",
        description: "Known for its fiery spices and tangy flavors, featuring dishes like Hyderabadi biryani, pesarattu, and gongura pickle. The cuisine balances heat with tamarind's tanginess and is famous for its extensive use of chilies and curry leaves."
      },
      {
        category: "Dance",
        name: "Kuchipudi",
        description: "Classical dance form originated in Andhra Pradesh, characterized by graceful movements, dramatic expressions, and storytelling. Performers often play multiple characters and include singing as an integral part of the performance."
      },
      {
        category: "Art",
        name: "Kalamkari",
        description: "Traditional hand-painted or block-printed cotton textile art featuring mythological stories and natural motifs. The art form uses natural dyes and is practiced in Srikalahasti and Machilipatnam."
      }
    ]
  },

  "arunachal-pradesh": {
    name: "Arunachal Pradesh",
    image: "/api/placeholder/800/400",
    description: "The land of the dawn-lit mountains, home to diverse tribal cultures and pristine natural beauty.",
    history: "Arunachal Pradesh, known as the 'Land of the Rising Sun,' has been inhabited by various tribal communities for centuries. The region remained largely isolated until British colonial times. The McMahon Line, drawn in 1914, became a significant geographical and political boundary. After independence, it was initially part of Assam, became a union territory in 1972, and achieved statehood in 1987. The state has strategic importance due to its border with China and Bhutan.",
    festivals: [
      {
        name: "Losar",
        significance: "Tibetan New Year celebration",
        description: "Celebrated by the Monpa tribe, marking the beginning of the lunar new year.",
        celebration: "Monasteries are decorated, traditional dances performed, and special foods like khapse (deep-fried pastries) are prepared. Prayers are offered for prosperity and peace."
      },
      {
        name: "Ziro Festival",
        significance: "Music festival celebrating tribal culture",
        description: "Outdoor music festival showcasing local and international artists in the picturesque Ziro valley.",
        celebration: "Four-day festival featuring music performances, local craft exhibitions, and cultural exchanges with the Apatani tribe."
      }
    ],
    monuments: [
      {
        name: "Tawang Monastery",
        location: "Tawang",
        bestSeason: "April to October",
        description: "Second largest monastery in the world, center of Tibetan Buddhism in India."
      },
      {
        name: "Bomdila Monastery",
        location: "Bomdila",
        bestSeason: "March to October",
        description: "Beautiful monastery offering panoramic views of the Himalayas."
      },
      {
        name: "Ziro Valley",
        location: "Lower Subansiri",
        bestSeason: "March to October",
        description: "UNESCO World Heritage site known for its unique Apatani culture."
      },
      {
        name: "Sela Pass",
        location: "Tawang",
        bestSeason: "May to October",
        description: "High altitude mountain pass at 13,700 feet with pristine alpine lakes."
      },
      {
        name: "Namdapha National Park",
        location: "Changlang",
        bestSeason: "November to March",
        description: "Biodiversity hotspot home to tigers, leopards, and red pandas."
      },
      {
        name: "Bumla Pass",
        location: "Tawang",
        bestSeason: "May to October",
        description: "Border pass between India and China with historical significance."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Tribal Diversity",
        description: "Home to 26 major tribes and over 100 sub-tribes, each with distinct languages, customs, and traditions. The Apatani, Nyishi, Adi, and Monpa tribes have unique cultural practices and sustainable living methods."
      },
      {
        category: "Art",
        name: "Traditional Crafts",
        description: "Intricate bamboo and cane work, traditional weaving, and wood carving. The state is famous for its handloom textiles with geometric patterns and natural dyes."
      },
      {
        category: "Food",
        name: "Tribal Cuisine",
        description: "Simple yet flavorful cuisine featuring rice, meat, fish, and forest vegetables. Popular dishes include thukpa, momos, and zan (millet-based dish). Fermented foods and bamboo shoot preparations are common."
      }
    ]
  },

  "assam": {
    name: "Assam",
    image: "/api/placeholder/800/400",
    description: "The land of red rivers and blue hills, famous for tea gardens, wildlife, and rich cultural heritage.",
    history: "Assam has a rich history dating back to ancient times, mentioned in epics like Kalika Purana and Mahabharata. The Ahom dynasty ruled for 600 years (1228-1826), giving the state its name. The region witnessed several invasions including those by the Mughals and Burmese. British colonial rule brought tea cultivation, which transformed the state's economy. Assam played a crucial role in India's independence movement and has since been the gateway to Northeast India.",
    festivals: [
      {
        name: "Bihu",
        significance: "Agricultural festival marking seasons",
        description: "The most important festival of Assam, celebrated three times a year according to agricultural cycles.",
        celebration: "Rongali Bihu (spring) involves traditional dances, Bhogali Bihu (harvest) features community feasts, and Kongali Bihu (autumn) is observed quietly. People wear traditional attire, sing Bihu songs, and perform vigorous dances."
      },
      {
        name: "Ambubachi Mela",
        significance: "Celebration of goddess Kamakhya's fertility",
        description: "Annual festival at Kamakhya Temple celebrating the menstruation period of goddess Kamakhya.",
        celebration: "Thousands of devotees and tantric sadhus gather for this unique festival. The temple remains closed for three days and reopens with grand celebrations."
      }
    ],
    monuments: [
      {
        name: "Kamakhya Temple",
        location: "Guwahati",
        bestSeason: "October to April",
        description: "Ancient temple dedicated to goddess Kamakhya, one of the 51 Shakti Peethas."
      },
      {
        name: "Kaziranga National Park",
        location: "Golaghat",
        bestSeason: "November to April",
        description: "UNESCO World Heritage site, home to two-thirds of the world's one-horned rhinoceros."
      },
      {
        name: "Majuli Island",
        location: "Jorhat",
        bestSeason: "October to March",
        description: "World's largest river island, center of Assamese neo-Vaishnavite culture."
      },
      {
        name: "Sivasagar",
        location: "Sivasagar",
        bestSeason: "October to March",
        description: "Former capital of Ahom kingdom with numerous temples and palaces."
      },
      {
        name: "Manas National Park",
        location: "Barpeta",
        bestSeason: "November to March",
        description: "UNESCO World Heritage site known for tigers, elephants, and golden langurs."
      },
      {
        name: "Umananda Temple",
        location: "Guwahati",
        bestSeason: "October to March",
        description: "Temple on Peacock Island in the Brahmaputra, dedicated to Lord Shiva."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Assamese Cuisine",
        description: "Simple yet flavorful cuisine emphasizing fish, rice, and vegetables. Famous dishes include masor tenga (sour fish curry), aloo pitika (mashed potatoes), and duck curry. The cuisine uses minimal spices, allowing natural flavors to shine."
      },
      {
        category: "Art",
        name: "Traditional Handicrafts",
        description: "Renowned for silk weaving, especially Muga silk which is exclusive to Assam. Bell metal work, bamboo crafts, and traditional mask-making are also significant art forms."
      },
      {
        category: "Culture",
        name: "Tea Culture",
        description: "Assam produces some of the world's finest black tea. The tea gardens, established during British rule, have become integral to the state's identity and economy, employing millions of people."
      }
    ]
  },

  "bihar": {
    name: "Bihar",
    image: "/api/placeholder/800/400",
    description: "The land where Buddhism and Jainism originated, rich in ancient history and spiritual heritage.",
    history: "Bihar is one of India's oldest inhabited regions, with evidence of human settlement dating back to the Neolithic age. It was the seat of great empires including the Mauryas and Guptas. Buddha attained enlightenment at Bodh Gaya, making it a significant pilgrimage site. The region was ruled by various dynasties and was a center of learning with institutions like Nalanda and Vikramshila universities. During British rule, Bihar played a crucial role in the independence movement, being the birthplace of many freedom fighters.",
    festivals: [
      {
        name: "Sonepur Cattle Fair",
        significance: "Asia's largest cattle fair",
        description: "Month-long fair attracting traders from across Asia for livestock trading.",
        celebration: "Elephants, horses, and cattle are traded while cultural programs, folk dances, and religious activities take place. The fair combines commerce with spirituality."
      },
      {
        name: "Chhath Puja",
        significance: "Worship of Sun God and Chhathi Maiya",
        description: "Four-day festival dedicated to the Sun God and his consort, observed with great devotion.",
        celebration: "Devotees fast for days, stand in water bodies offering prayers to the setting and rising sun, and prepare traditional offerings like thekua and kheer."
      }
    ],
    monuments: [
      {
        name: "Mahabodhi Temple",
        location: "Bodh Gaya",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site where Buddha attained enlightenment under the Bodhi tree."
      },
      {
        name: "Nalanda University Ruins",
        location: "Nalanda",
        bestSeason: "October to March",
        description: "Ruins of ancient university that was a center of learning for over 800 years."
      },
      {
        name: "Vikramshila University Ruins",
        location: "Bhagalpur",
        bestSeason: "October to March",
        description: "Important center of Buddhist learning founded by King Dharmapala."
      },
      {
        name: "Golghar",
        location: "Patna",
        bestSeason: "October to March",
        description: "Granary built by British in 1786 to store grains during famines."
      },
      {
        name: "Rajgir Hot Springs",
        location: "Rajgir",
        bestSeason: "October to March",
        description: "Natural hot springs with religious significance in Buddhism and Jainism."
      },
      {
        name: "Kesaria Stupa",
        location: "Kesaria",
        bestSeason: "October to March",
        description: "Largest Buddhist stupa in the world, dating back to 200-750 CE."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Bihari Cuisine",
        description: "Simple yet delicious cuisine featuring litti chokha (baked wheat balls with mashed vegetables), sattu (roasted gram flour preparations), and fish curries. The cuisine reflects the agricultural heritage of the region."
      },
      {
        category: "Art",
        name: "Madhubani Painting",
        description: "Traditional folk art practiced by women of Mithila region, characterized by geometric patterns and mythological themes. Originally done on walls, it's now practiced on paper and canvas."
      },
      {
        category: "Culture",
        name: "Buddhist Heritage",
        description: "Bihar is the birthplace of Buddhism, with numerous monasteries, stupas, and meditation centers. The state attracts Buddhist pilgrims from around the world, especially to Bodh Gaya."
      }
    ]
  },

  "chhattisgarh": {
    name: "Chhattisgarh",
    image: "/api/placeholder/800/400",
    description: "The rice bowl of India, known for its tribal culture, natural beauty, and mineral wealth.",
    history: "Chhattisgarh has ancient roots, mentioned in epics like Ramayana and Mahabharata. The region was ruled by various dynasties including the Satavahanas, Vakatakas, and Kalachuris. The area was known for its 36 forts (Chhattisgarh means 36 forts). During medieval times, it was part of various kingdoms including the Marathas. Under British rule, it was part of the Central Provinces. The state was carved out of Madhya Pradesh in 2000, becoming India's 26th state.",
    festivals: [
      {
        name: "Bastar Dussehra",
        significance: "Unique 75-day celebration",
        description: "The longest Dussehra celebration in the world, unique to the tribal culture of Bastar.",
        celebration: "Unlike other parts of India, here Dussehra celebrates goddess Danteshwari. The festival involves elaborate rituals, traditional dances, and a grand chariot procession."
      },
      {
        name: "Hareli",
        significance: "Agricultural festival marking the start of farming",
        description: "Festival celebrated to mark the beginning of the sowing season.",
        celebration: "Farmers worship their cattle and agricultural tools. Traditional games, folk dances, and community feasts are organized."
      }
    ],
    monuments: [
      {
        name: "Chitrakote Falls",
        location: "Bastar",
        bestSeason: "July to February",
        description: "Known as the 'Niagara of India', widest waterfall in the country."
      },
      {
        name: "Kanger Valley National Park",
        location: "Bastar",
        bestSeason: "October to June",
        description: "Home to diverse wildlife and famous for limestone caves."
      },
      {
        name: "Sirpur Archaeological Site",
        location: "Mahasamund",
        bestSeason: "October to March",
        description: "Ancient site with Buddhist, Hindu, and Jain monuments dating from 5th-12th centuries."
      },
      {
        name: "Bhilai Steel Plant",
        location: "Bhilai",
        bestSeason: "October to March",
        description: "One of India's largest steel plants, symbol of industrial development."
      },
      {
        name: "Achanakmar Wildlife Sanctuary",
        location: "Bilaspur",
        bestSeason: "November to June",
        description: "Part of Achanakmar-Amarkantak Biosphere Reserve, home to tigers and leopards."
      },
      {
        name: "Ratanpur",
        location: "Bilaspur",
        bestSeason: "October to March",
        description: "Ancient capital with numerous temples and historical significance."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Tribal Heritage",
        description: "Home to numerous tribal communities including Gonds, Baigas, and Oraons. Each tribe has distinct customs, languages, art forms, and traditional knowledge systems related to forest conservation."
      },
      {
        category: "Art",
        name: "Tribal Arts and Crafts",
        description: "Rich tradition of tribal art including Pithora paintings, bamboo crafts, bell metal work, and traditional jewelry. The art often depicts nature, animals, and tribal deities."
      },
      {
        category: "Food",
        name: "Tribal Cuisine",
        description: "Simple forest-based cuisine featuring rice, lentils, and forest vegetables. Popular dishes include bore basi (fermented rice), bhajia (vegetable fritters), and various preparations using mahua flowers and leaves."
      }
    ]
  },

  "goa": {
    name: "Goa",
    image: "/api/placeholder/800/400",
    description: "India's beach paradise, known for its Portuguese heritage, vibrant culture, and stunning coastline.",
    history: "Goa has a unique history shaped by Portuguese colonization for over 450 years (1510-1961). Before Portuguese rule, it was governed by various dynasties including the Kadambas, Vijayanagara Empire, and Adil Shahis. The Portuguese influence is evident in architecture, cuisine, and culture. The region became famous for its spice trade and was an important colonial outpost. Goa was liberated in 1961 and became a union territory, later achieving statehood in 1987. The blend of Indian and Portuguese cultures makes Goa unique in India.",
    festivals: [
      {
        name: "Carnival",
        significance: "Portuguese-influenced celebration before Lent",
        description: "Colorful festival introduced by Portuguese, celebrated with parades and festivities.",
        celebration: "Three-day celebration featuring elaborate floats, masked dancers, music, and street parties. King Momo leads the festivities, and people dress in vibrant costumes."
      },
      {
        name: "Shigmo",
        significance: "Goan version of Holi celebrating spring",
        description: "Traditional Hindu festival celebrating the arrival of spring and harvest season.",
        celebration: "Colorful processions with elaborate floats depicting mythological stories, folk dances, and traditional music. Communities organize cultural programs and feasts."
      }
    ],
    monuments: [
      {
        name: "Basilica of Bom Jesus",
        location: "Old Goa",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site holding the mortal remains of St. Francis Xavier."
      },
      {
        name: "Se Cathedral",
        location: "Old Goa",
        bestSeason: "October to March",
        description: "One of the largest churches in Asia, known for its Portuguese architecture."
      },
      {
        name: "Fort Aguada",
        location: "Sinquerim",
        bestSeason: "October to March",
        description: "17th-century Portuguese fort overlooking the Arabian Sea."
      },
      {
        name: "Dudhsagar Falls",
        location: "Sanguem",
        bestSeason: "June to September",
        description: "Four-tiered waterfall resembling flowing milk, one of India's tallest."
      },
      {
        name: "Chapora Fort",
        location: "Bardez",
        bestSeason: "October to March",
        description: "Portuguese fort offering panoramic views, famous from Bollywood movies."
      },
      {
        name: "Church of Our Lady of Immaculate Conception",
        location: "Panaji",
        bestSeason: "October to March",
        description: "Iconic whitewashed church with zigzag steps, symbol of Panaji."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Goan Cuisine",
        description: "Unique blend of Indian and Portuguese flavors featuring coconut, seafood, and spices. Famous dishes include fish curry rice, vindaloo, bebinca, and feni (local spirit made from cashew or palm)."
      },
      {
        category: "Music",
        name: "Goan Music",
        description: "Rich musical tradition blending Indian classical, folk, and Portuguese influences. Konkani songs, mandó ballads, and modern Goan music reflect this cultural fusion."
      },
      {
        category: "Architecture",
        name: "Indo-Portuguese Architecture",
        description: "Unique architectural style combining Indian and Portuguese elements seen in churches, houses, and public buildings. Features include ornate facades, azulejos (blue tiles), and traditional Goan houses with large windows and verandas."
      }
    ]
  },

  "gujarat": {
    name: "Gujarat",
    image: "/api/placeholder/800/400",
    description: "The vibrant state of Gujarat is known for its entrepreneurial spirit, colorful culture, and significant contributions to India's freedom struggle.",
    history: "Gujarat has been a cradle of civilization for over 4,000 years, with the ancient Indus Valley Civilization's major sites located here. The region was part of various empires including the Mauryas, Guptas, and later the Chalukyas and Solankis who built magnificent temples and cities. The medieval period saw the rise of the Gujarat Sultanate, which made the region a major trading hub. The Mughal period brought prosperity through trade, and later the Marathas controlled the region. Gujarat played a crucial role in India's independence movement, being the birthplace of Mahatma Gandhi and the location where the Salt March began. The state's mercantile communities developed extensive trade networks across the Indian Ocean, contributing to its prosperity and cultural diversity.",
    festivals: [
      {
        name: "Navratri",
        significance: "Nine nights celebrating Goddess Durga",
        description: "Gujarat's most famous festival, celebrating the divine feminine power through nine nights of devotional dancing and music.",
        celebration: "People gather in large numbers to perform Garba and Dandiya Raas dances around decorated clay pots with oil lamps. Colorful traditional attire, rhythmic music, and community participation make this festival a spectacular cultural event attracting visitors from around the world."
      },
      {
        name: "Kite Festival (Uttarayan)",
        significance: "Celebration of sun's northward journey",
        description: "International Kite Festival marking the transition of the sun into the northern hemisphere, celebrated with great enthusiasm across Gujarat.",
        celebration: "The sky fills with colorful kites of all shapes and sizes. People compete in kite flying from rooftops, and the festival includes traditional food like undhiyu and chikki. The night sky is illuminated with special box kites fitted with lights and fireworks."
      },
      {
        name: "Rath Yatra",
        significance: "Lord Jagannath's chariot procession",
        description: "Famous chariot festival of Lord Jagannath celebrated with great fervor in Gujarat, especially in coastal areas.",
        celebration: "Massive wooden chariots are pulled through the streets by thousands of devotees. The festival includes cultural programs, food stalls, and religious ceremonies, creating a carnival-like atmosphere."
      }
    ],
    monuments: [
      {
        name: "Rani ki Vav",
        location: "Patan",
        bestSeason: "October to March",
        description: "UNESCO World Heritage stepwell showcasing the pinnacle of Indian architecture with intricate carvings and sculptures."
      },
      {
        name: "Somnath Temple",
        location: "Somnath",
        bestSeason: "October to March",
        description: "One of the twelve Jyotirlingas of Lord Shiva, rebuilt multiple times and symbolizing the resilience of faith."
      },
      {
        name: "Dwarkadhish Temple",
        location: "Dwarka",
        bestSeason: "October to March",
        description: "Ancient temple dedicated to Lord Krishna, believed to be built over the legendary city of Dwarka."
      },
      {
        name: "Sabarmati Ashram",
        location: "Ahmedabad",
        bestSeason: "October to March",
        description: "Mahatma Gandhi's residence and the starting point of the historic Salt March, now a museum preserving his legacy."
      },
      {
        name: "Great Rann of Kutch",
        location: "Kutch",
        bestSeason: "November to February",
        description: "World's largest salt desert that transforms into a white wonderland during winter, hosting the vibrant Rann Utsav festival."
      },
      {
        name: "Adalaj Stepwell",
        location: "Gandhinagar",
        bestSeason: "October to March",
        description: "Intricately carved stepwell showcasing Indo-Islamic architecture with beautiful stone carvings and cooling system."
      },
      {
        name: "Gir National Park",
        location: "Junagadh",
        bestSeason: "December to March",
        description: "Last natural habitat of Asiatic lions and home to diverse wildlife including leopards, hyenas, and various bird species."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Gujarati Thali",
        description: "A complete vegetarian meal served on a large plate with multiple bowls containing various dishes like dal, kadhi, vegetables, rotli, rice, and sweets. The thali represents the philosophy of balance in flavors - sweet, salty, spicy, and tangy - and is typically unlimited, reflecting Gujarati hospitality."
      },
      {
        category: "Art",
        name: "Bandhani Tie-Dye",
        description: "Traditional tie-dye art form creating beautiful patterns on fabric through a resist-dyeing technique. Kutch and Saurashtra regions are famous for this craft, producing colorful textiles worn during festivals and special occasions."
      },
      {
        category: "Traditions",
        name: "Business Acumen",
        description: "Gujaratis are renowned worldwide for their entrepreneurial skills and business acumen. The state has produced many successful business leaders and has a strong tradition of trade and commerce dating back centuries."
      },
      {
        category: "Dance",
        name: "Garba and Dandiya",
        description: "Traditional folk dances performed during Navratri, characterized by circular movements, rhythmic clapping, and the use of decorated sticks (dandiya). These dances celebrate the divine feminine and bring communities together in joyous celebration."
      },
      {
        category: "Handicrafts",
        name: "Traditional Crafts",
        description: "Gujarat is famous for various handicrafts including mirror work, embroidery, woodcarving, and metal work. Kutch region is particularly known for its intricate embroidery and crafts practiced by various tribal communities."
      }
    ]
  },

  "haryana": {
    name: "Haryana",
    image: "/api/placeholder/800/400",
    description: "The land of agricultural prosperity and ancient heritage, birthplace of the Bhagavad Gita.",
    history: "Haryana has been a significant region since ancient times, mentioned in Hindu epics as Brahmavarta and Aryavarta. The epic battle of Kurukshetra from Mahabharata was fought here, where Lord Krishna delivered the Bhagavad Gita. The region saw the rise and fall of various empires including the Mauryas, Guptas, and later the Mughals. During the British period, it was part of Punjab province. After independence and the reorganization of states, Haryana was carved out of Punjab in 1966. The state played a crucial role in India's Green Revolution.",
    festivals: [
      {
        name: "Baisakhi",
        significance: "Harvest festival marking new agricultural year",
        description: "Celebration of wheat harvest and traditional new year in the agricultural calendar.",
        celebration: "Farmers express gratitude for good harvest, perform folk dances like Bhangra and Gidda, and participate in fairs and cultural programs."
      },
      {
        name: "Teej",
        significance: "Monsoon festival celebrating marital bliss",
        description: "Festival celebrating the arrival of monsoon and honoring the bond between husband and wife.",
        celebration: "Women wear green clothes, apply henna, swing on decorated swings, and sing traditional songs. Special foods and sweets are prepared."
      }
    ],
    monuments: [
      {
        name: "Kurukshetra",
        location: "Kurukshetra",
        bestSeason: "October to March",
        description: "Sacred land where the Mahabharata war was fought and Bhagavad Gita was delivered."
      },
      {
        name: "Sultanpur National Park",
        location: "Sultanpur",
        bestSeason: "November to March",
        description: "Bird sanctuary attracting migratory birds from Europe and Siberia."
      },
      {
        name: "Pinjore Gardens",
        location: "Pinjore",
        bestSeason: "October to March",
        description: "Mughal garden built in 17th century with terraced lawns and fountains."
      },
      {
        name: "Blue Bird Lake",
        location: "Hisar",
        bestSeason: "October to March",
        description: "Artificial lake attracting various migratory birds, popular for bird watching."
      },
      {
        name: "Brahma Sarovar",
        location: "Kurukshetra",
        bestSeason: "October to March",
        description: "Sacred water tank mentioned in Hindu scriptures, site of solar eclipse fairs."
      },
      {
        name: "Kalesar National Park",
        location: "Yamunanagar",
        bestSeason: "November to June",
        description: "Dense forest area preserving Sal trees and wildlife including leopards and elephants."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Agricultural Heritage",
        description: "Haryana is known as India's breadbasket, contributing significantly to the country's food grain production. The state pioneered the Green Revolution and maintains strong agricultural traditions."
      },
      {
        category: "Sports",
        name: "Wrestling Tradition",
        description: "Haryana has produced numerous international wrestlers and is known for its akhadas (wrestling schools). The state has a strong sporting culture, especially in wrestling, boxing, and athletics."
      },
      {
        category: "Food",
        name: "Haryanvi Cuisine",
        description: "Hearty North Indian cuisine featuring dairy products, wheat, and seasonal vegetables. Popular dishes include kadhi pakora, bajre ki roti with makhan, and various stuffed breads."
      }
    ]
  },

  "himachal-pradesh": {
    name: "Himachal Pradesh",
    image: "/api/placeholder/800/400",
    description: "The land of snow-capped mountains, apple orchards, and ancient hill temples.",
    history: "Himachal Pradesh's history is deeply rooted in Hindu mythology and ancient kingdoms. The region was ruled by various Rajput kingdoms and later came under Mughal influence. The British established hill stations like Shimla, which became the summer capital of British India. After independence, various princely states were merged to form Himachal Pradesh in 1971. The state has maintained its cultural heritage while developing as a popular tourist destination.",
    festivals: [
      {
        name: "Kullu Dussehra",
        significance: "Unique celebration honoring Lord Raghunath",
        description: "Week-long festival beginning when Dussehra ends elsewhere in India, featuring a grand procession of deities.",
        celebration: "Hundreds of local deities are brought in palanquins to pay homage to Lord Raghunath. The festival includes cultural performances, traditional music, and a vibrant fair."
      },
      {
        name: "Ice Skating Carnival",
        significance: "Winter sports celebration",
        description: "Annual carnival celebrating winter sports and ice skating in Shimla.",
        celebration: "Ice skating competitions, winter sports demonstrations, and cultural programs are organized. The event attracts tourists and promotes winter tourism."
      }
    ],
    monuments: [
      {
        name: "Shimla Ridge",
        location: "Shimla",
        bestSeason: "March to June, October to February",
        description: "Historic ridge offering panoramic mountain views and colonial architecture."
      },
      {
        name: "Rohtang Pass",
        location: "Manali",
        bestSeason: "May to October",
        description: "High mountain pass offering spectacular views and gateway to Lahaul-Spiti."
      },
      {
        name: "Hadimba Temple",
        location: "Manali",
        bestSeason: "March to June, September to November",
        description: "Ancient temple dedicated to Hadimba Devi, built in pagoda style architecture."
      },
      {
        name: "Great Himalayan National Park",
        location: "Kullu",
        bestSeason: "April to June, September to November",
        description: "UNESCO World Heritage site preserving high-altitude biodiversity."
      },
      {
        name: "Spiti Valley",
        location: "Lahaul and Spiti",
        bestSeason: "June to September",
        description: "High-altitude desert valley known for ancient monasteries and stunning landscapes."
      },
      {
        name: "Dharamshala",
        location: "Kangra",
        bestSeason: "March to June, September to November",
        description: "Hill station and residence of the Dalai Lama, center of Tibetan culture in India."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Hill Culture",
        description: "Rich traditions of hill communities with unique festivals, folk songs, and dances. The state preserves ancient Pahari culture and traditions while embracing modernity."
      },
      {
        category: "Art",
        name: "Pahari Paintings",
        description: "Traditional miniature paintings from the hill regions depicting religious themes, court scenes, and folk tales. Different schools like Kangra, Basohli, and Chamba have distinct styles."
      },
      {
        category: "Food",
        name: "Himachali Cuisine",
        description: "Mountain cuisine featuring dishes like dham (festive meal), siddu (steamed bread), and chana madra (chickpeas in yogurt curry). The cuisine uses local ingredients and traditional cooking methods."
      }
    ]
  },

  "jharkhand": {
    name: "Jharkhand",
    image: "/api/placeholder/800/400",
    description: "The land of forests and minerals, rich in tribal culture and natural resources.",
    history: "Jharkhand, meaning 'forest land,' has been inhabited by tribal communities for thousands of years. The region was part of various empires including the Mauryas, Guptas, and later the Mughals. During British rule, it was known for tribal uprisings against colonial exploitation. The area was part of Bihar until 2000, when it became a separate state. Jharkhand is rich in mineral resources and has a significant tribal population maintaining traditional lifestyles.",
    festivals: [
      {
        name: "Sarhul",
        significance: "Tribal festival worshipping nature",
        description: "Most important festival of tribal communities, celebrating the relationship between nature and humans.",
        celebration: "Worship of sal trees, traditional dances, and community feasts are organized. The festival marks the beginning of the new year and agricultural activities."
      },
      {
        name: "Karma Puja",
        significance: "Festival celebrating brotherhood and friendship",
        description: "Tribal festival dedicated to Karma Devta, the god of power and youth.",
        celebration: "Unmarried girls observe fast and pray for good husbands, while boys and girls dance together around the Karma tree. Traditional songs and dances continue through the night."
      }
    ],
    monuments: [
      {
        name: "Betla National Park",
        location: "Latehar",
        bestSeason: "November to May",
        description: "First national park in Jharkhand, home to tigers, elephants, and sloth bears."
      },
      {
        name: "Hundru Falls",
        location: "Ranchi",
        bestSeason: "July to February",
        description: "Spectacular waterfall cascading from 98 meters, formed by the Subarnarekha River."
      },
      {
        name: "Jagannath Temple",
        location: "Ranchi",
        bestSeason: "October to March",
        description: "Replica of Puri's Jagannath Temple, important pilgrimage site in Jharkhand."
      },
      {
        name: "Dassam Falls",
        location: "Ranchi",
        bestSeason: "July to February",
        description: "Beautiful waterfall formed by Kanchi River, popular picnic spot and filming location."
      },
      {
        name: "Hazaribagh National Park",
        location: "Hazaribagh",
        bestSeason: "October to April",
        description: "Wildlife sanctuary known for its biodiversity and tiger reserve."
      },
      {
        name: "Parasnath Hill",
        location: "Giridih",
        bestSeason: "October to March",
        description: "Highest peak in Jharkhand and important Jain pilgrimage site."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Tribal Heritage",
        description: "Home to numerous tribal communities including Santhal, Munda, Oraon, and Ho tribes. Each community has distinct languages, customs, art forms, and traditional knowledge systems."
      },
      {
        category: "Art",
        name: "Tribal Arts",
        description: "Rich tradition of tribal art including Paitkar paintings, traditional jewelry, bamboo crafts, and handloom textiles. The art often depicts nature, tribal deities, and daily life."
      },
      {
        category: "Food",
        name: "Tribal Cuisine",
        description: "Simple forest-based cuisine featuring rice, lentils, vegetables, and meat. Popular dishes include dhuska (rice flour fritters), pitha (rice cakes), and various preparations using forest produce."
      }
    ]
  },

  "karnataka": {
    name: "Karnataka",
    image: "/api/placeholder/800/400",
    description: "The land of magnificent palaces, ancient temples, and India's Silicon Valley.",
    history: "Karnataka has a rich history spanning over 2,000 years, ruled by powerful dynasties like the Chalukyas, Rashtrakutas, Hoysalas, and Vijayanagara Empire. The region witnessed the rise of great kingdoms that patronized art, architecture, and literature. The Mysore Kingdom under Tipu Sultan played a significant role in resisting British colonization. Post-independence, the state was formed by uniting Kannada-speaking regions. Karnataka has emerged as India's IT capital while preserving its cultural heritage.",
    festivals: [
      {
        name: "Mysore Dasara",
        significance: "Royal celebration of victory of good over evil",
        description: "Grand 10-day festival celebrating the victory of goddess Chamundeshwari over the demon Mahishasura.",
        celebration: "The Mysore Palace is illuminated with thousands of lights, royal processions with decorated elephants, cultural performances, and the famous Jamboo Savari (elephant procession) mark the celebrations."
      },
      {
        name: "Karaga",
        significance: "Festival honoring goddess Draupadi",
        description: "Annual festival in Bangalore dedicated to goddess Draupadi, celebrated by the Vahnikula Kshatriya community.",
        celebration: "A sacred pot (karaga) is carried by the priest in a trance-like state through the streets, accompanied by hundreds of devotees carrying unsheathed swords and performing traditional dances."
      }
    ],
    monuments: [
      {
        name: "Hampi",
        location: "Bellary",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, ruins of the magnificent Vijayanagara Empire."
      },
      {
        name: "Mysore Palace",
        location: "Mysore",
        bestSeason: "October to March",
        description: "Opulent palace showcasing Indo-Saracenic architecture, former residence of Mysore royalty."
      },
      {
        name: "Gol Gumbaz",
        location: "Bijapur",
        bestSeason: "October to March",
        description: "Mausoleum with the second largest dome in the world, famous for its acoustic properties."
      },
      {
        name: "Pattadakal",
        location: "Bagalkot",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site showcasing Chalukyan architecture with Hindu and Jain temples."
      },
      {
        name: "Coorg (Kodagu)",
        location: "Kodagu",
        bestSeason: "October to March",
        description: "Hill station known for coffee plantations, spice gardens, and scenic beauty."
      },
      {
        name: "Badami Caves",
        location: "Bagalkot",
        bestSeason: "October to March",
        description: "Rock-cut caves dating from 6th century showcasing Chalukyan art and architecture."
      },
      {
        name: "Jog Falls",
        location: "Shimoga",
        bestSeason: "August to December",
        description: "One of India's highest waterfalls, cascading from a height of 830 feet."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Karnataka Cuisine",
        description: "Diverse cuisine varying by region, from coastal seafood curries to North Karnataka's spicy dishes. Famous items include masala dosa, bisi bele bath, Mysore pak, and filter coffee."
      },
      {
        category: "Music",
        name: "Carnatic Music",
        description: "Karnataka has a rich tradition of Carnatic classical music with legendary composers like Purandara Dasa. The state continues to nurture this art form through various festivals and institutions."
      },
      {
        category: "Art",
        name: "Traditional Crafts",
        description: "Famous for silk weaving (especially Mysore silk), sandalwood carving, Channapatna toys, and traditional paintings. The state maintains these ancient crafts while promoting contemporary art."
      },
      {
        category: "Dance",
        name: "Yakshagana",
        description: "Traditional theater form combining dance, music, dialogue, and elaborate costumes. Performances usually depict stories from Hindu epics and puranas, particularly popular in coastal Karnataka."
      }
    ]
  },

  "kerala": {
    name: "Kerala",
    image: "/api/placeholder/800/400",
    description: "Known as 'God's Own Country', Kerala is a tropical paradise with pristine backwaters, lush greenery, and rich cultural traditions.",
    history: "Kerala's history is deeply intertwined with maritime trade and cultural exchange. The state has been a major spice trading center since ancient times, attracting merchants from Arabia, China, and Europe. The region was ruled by various dynasties including the Cheras, Cholas, and later the Zamorins of Calicut. European colonization began with the Portuguese in 1498 when Vasco da Gama landed in Calicut, followed by the Dutch and British. The state has a unique history of social reforms, with the kingdom of Travancore being one of the first to abolish untouchability. Kerala also witnessed the rise of communism in India and has maintained high literacy rates and progressive social policies. The state's matrilineal system among certain communities and its tradition of religious tolerance have made it unique in the Indian context.",
    festivals: [
      {
        name: "Onam",
        significance: "Harvest festival celebrating King Mahabali's return",
        description: "The most important festival of Kerala, celebrating the golden era of the mythical King Mahabali and the rice harvest.",
        celebration: "Ten-day celebrations include Pookalam (flower carpets), traditional dance performances like Thiruvathira and Pulikali, boat races, and the grand Onasadya feast with 26 traditional dishes served on banana leaves."
      },
      {
        name: "Thrissur Pooram",
        significance: "Temple festival honoring Lord Shiva",
        description: "One of Kerala's most spectacular temple festivals, known for its grandeur and magnificent elephant processions.",
        celebration: "Decorated elephants carrying colorful umbrellas and traditional ornaments parade through the streets. The festival features traditional percussion ensembles, fireworks display, and thousands of devotees participating in the celebrations."
      },
      {
        name: "Theyyam",
        significance: "Ritualistic folk art form worshipping local deities",
        description: "A unique ritualistic art form of North Kerala where performers become living gods through elaborate costumes and makeup.",
        celebration: "Performers undergo transformation through intricate face painting, costumes, and ornaments, then dance in a trance-like state believed to invoke divine presence. Communities seek blessings and solutions to problems through these divine manifestations."
      }
    ],
    monuments: [
      {
        name: "Backwaters of Alleppey",
        location: "Alappuzha",
        bestSeason: "October to February",
        description: "A network of lagoons, lakes, and canals lined with palm trees, offering serene houseboat cruises through Kerala's unique ecosystem."
      },
      {
        name: "Mattancherry Palace",
        location: "Kochi",
        bestSeason: "October to March",
        description: "Also known as the Dutch Palace, featuring beautiful murals depicting scenes from Hindu epics and showcasing Kerala's architectural heritage."
      },
      {
        name: "Padmanabhaswamy Temple",
        location: "Thiruvananthapuram",
        bestSeason: "October to March",
        description: "An ancient temple dedicated to Lord Vishnu, famous for its Dravidian architecture and being one of the richest temples in the world."
      },
      {
        name: "Chinese Fishing Nets",
        location: "Fort Kochi",
        bestSeason: "October to March",
        description: "Iconic cantilevered fishing nets introduced by Chinese traders, now a symbol of Kochi's maritime heritage."
      },
      {
        name: "Hill Palace Museum",
        location: "Tripunithura",
        bestSeason: "October to March",
        description: "Former residence of the Kochi royal family, now a museum displaying artifacts, paintings, and royal belongings."
      },
      {
        name: "Bekal Fort",
        location: "Kasaragod",
        bestSeason: "October to March",
        description: "A well-preserved coastal fort built by Keladi Nayakas, offering stunning views of the Arabian Sea."
      },
      {
        name: "Athirapally Waterfalls",
        location: "Thrissur",
        bestSeason: "June to September (monsoon)",
        description: "Often called the 'Niagara of India', these spectacular waterfalls cascade down from 80 feet through lush green forests."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Sadya",
        description: "Traditional vegetarian feast served on banana leaves during festivals, featuring 26 different dishes including sambar, rasam, aviyal, and payasam. Each dish has its specific place on the leaf and is eaten in a particular order, representing the perfect balance of flavors and nutrition."
      },
      {
        category: "Art",
        name: "Kathakali",
        description: "Classical dance-drama of Kerala known for its elaborate costumes, intricate makeup, and expressive gestures. Performers train for years to master the complex facial expressions and hand movements that tell stories from Hindu epics without spoken words."
      },
      {
        category: "Music",
        name: "Carnatic Music",
        description: "Kerala has a rich tradition of Carnatic classical music with unique ragas and compositions. The state has produced legendary musicians and continues to nurture this art form through various music festivals and institutions."
      },
      {
        category: "Dance",
        name: "Mohiniyattam",
        description: "Classical dance form of Kerala performed by women, characterized by graceful movements and subtle expressions. The dance tells stories of love and devotion through fluid movements that resemble the swaying of palm trees and the flow of backwaters."
      },
      {
        category: "Traditions",
        name: "Ayurveda",
        description: "Kerala is the birthplace of Ayurveda, the ancient Indian system of medicine. The state maintains traditional knowledge of herbal medicines, treatments, and wellness practices that attract people from around the world seeking authentic Ayurvedic healing."
      }
    ]
  },

  "madhya-pradesh": {
    name: "Madhya Pradesh",
    image: "/api/placeholder/800/400",
    description: "The heart of India, rich in wildlife, ancient temples, and historical monuments.",
    history: "Madhya Pradesh, literally meaning 'Central Province,' has been the heart of India's cultural and political evolution. The region has witnessed the rise of great empires including the Mauryas, Guptas, and later the Paramara and Chandela dynasties. The state is home to some of India's finest temple architecture, particularly the Khajuraho temples. During medieval times, it was ruled by various Muslim dynasties and later the Marathas. The British created the Central Provinces, and after independence, the modern state of Madhya Pradesh was formed through reorganization.",
    festivals: [
      {
        name: "Khajuraho Dance Festival",
        significance: "Celebration of classical Indian dance forms",
        description: "Annual festival showcasing India's classical dance traditions against the backdrop of ancient temples.",
        celebration: "Renowned artists perform various classical dance forms like Bharatanatyam, Kathak, Kuchipudi, and Odissi. The temple sculptures come alive through these performances under moonlit nights."
      },
      {
        name: "Malwa Utsav",
        significance: "Cultural festival celebrating Malwa region's heritage",
        description: "Festival showcasing the rich cultural heritage of the Malwa region through folk arts, crafts, and performances.",
        celebration: "Folk dances, traditional music, handicraft exhibitions, and local cuisine are featured. The festival promotes the region's cultural identity and tourism."
      }
    ],
    monuments: [
      {
        name: "Khajuraho Temples",
        location: "Khajuraho",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site famous for exquisite temple architecture and sculptures."
      },
      {
        name: "Sanchi Stupa",
        location: "Sanchi",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, oldest stone structure in India built by Emperor Ashoka."
      },
      {
        name: "Kanha National Park",
        location: "Mandla",
        bestSeason: "October to June",
        description: "One of India's finest tiger reserves, inspiration for Rudyard Kipling's Jungle Book."
      },
      {
        name: "Bhimbetka Rock Shelters",
        location: "Raisen",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site with prehistoric cave paintings dating back 30,000 years."
      },
      {
        name: "Gwalior Fort",
        location: "Gwalior",
        bestSeason: "October to March",
        description: "Hilltop fort known for its architectural grandeur and historical significance."
      },
      {
        name: "Ujjain",
        location: "Ujjain",
        bestSeason: "October to March",
        description: "Ancient city and one of the seven sacred cities in Hinduism, host to Kumbh Mela."
      },
      {
        name: "Pachmarhi",
        location: "Hoshangabad",
        bestSeason: "October to June",
        description: "Only hill station in Madhya Pradesh, known for waterfalls and archaeological sites."
      }
    ],
    culturalHighlights: [
      {
        category: "Wildlife",
        name: "Tiger Conservation",
        description: "Madhya Pradesh has the highest tiger population in India with several tiger reserves including Kanha, Bandhavgarh, and Pench. The state has been successful in tiger conservation efforts."
      },
      {
        category: "Art",
        name: "Gond Art",
        description: "Traditional tribal art form of the Gond community, characterized by intricate patterns and vibrant colors depicting nature, animals, and folklore. This art has gained international recognition."
      },
      {
        category: "Food",
        name: "Malwa Cuisine",
        description: "Rich vegetarian cuisine featuring dishes like dal bafla, poha, and various sweets. The cuisine reflects the agricultural abundance of the region and traditional cooking methods."
      }
    ]
  },

  "maharashtra": {
    name: "Maharashtra",
    image: "/api/placeholder/800/400",
    description: "The land of forts and festivals, home to Bollywood and India's financial capital Mumbai.",
    history: "Maharashtra has a glorious history spanning ancient, medieval, and modern periods. The region was ruled by various dynasties including the Satavahanas, Chalukyas, and Rashtrakutas. The medieval period saw the rise of the Maratha Empire under Chhatrapati Shivaji Maharaj, who established a powerful Hindu kingdom. The Marathas became a dominant force in Indian politics until the British colonial period. The state played a crucial role in India's independence movement and social reform movements. Post-independence, Maharashtra emerged as India's industrial and financial powerhouse.",
    festivals: [
      {
        name: "Ganesh Chaturthi",
        significance: "Celebration honoring Lord Ganesha",
        description: "Most popular festival in Maharashtra, celebrating the elephant-headed god Ganesha with great devotion and enthusiasm.",
        celebration: "Elaborate clay idols of Ganesha are installed in homes and public pandals, followed by grand processions and immersion in water bodies after 1.5, 5, 7, or 11 days of worship."
      },
      {
        name: "Gudi Padwa",
        significance: "Marathi New Year celebration",
        description: "Traditional new year festival marking the beginning of spring and agricultural activities.",
        celebration: "People hoist colorful gudis (flags) outside their homes, prepare traditional foods, exchange greetings, and wear new clothes. The festival symbolizes victory and prosperity."
      }
    ],
    monuments: [
      {
        name: "Ajanta Caves",
        location: "Aurangabad",
        bestSeason: "November to March",
        description: "UNESCO World Heritage site with ancient Buddhist cave paintings and sculptures."
      },
      {
        name: "Ellora Caves",
        location: "Aurangabad",
        bestSeason: "November to March",
        description: "UNESCO World Heritage site showcasing Buddhist, Hindu, and Jain cave temples."
      },
      {
        name: "Shivneri Fort",
        location: "Pune",
        bestSeason: "October to March",
        description: "Birthplace of Chhatrapati Shivaji Maharaj, offering insights into Maratha history."
      },
      {
        name: "Gateway of India",
        location: "Mumbai",
        bestSeason: "November to February",
        description: "Iconic monument built to commemorate the visit of King George V and Queen Mary."
      },
      {
        name: "Raigad Fort",
        location: "Raigad",
        bestSeason: "October to March",
        description: "Capital of Maratha Empire under Shivaji Maharaj, showcasing Maratha architecture."
      },
      {
        name: "Lonar Crater Lake",
        location: "Buldhana",
        bestSeason: "November to March",
        description: "Unique crater lake formed by meteor impact, surrounded by ancient temples."
      },
      {
        name: "Mahabaleshwar",
        location: "Satara",
        bestSeason: "October to June",
        description: "Popular hill station known for strawberries, scenic viewpoints, and pleasant climate."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Maharashtrian Cuisine",
        description: "Diverse cuisine varying from coastal Konkani dishes to spicy Vidarbha foods. Popular dishes include vada pav, misal pav, puran poli, and bhel puri. The cuisine reflects the state's agricultural diversity."
      },
      {
        category: "Culture",
        name: "Maratha Heritage",
        description: "Rich legacy of the Maratha Empire with numerous forts, palaces, and historical sites. The state takes pride in its warrior culture and the legacy of Chhatrapati Shivaji Maharaj."
      },
      {
        category: "Entertainment",
        name: "Bollywood",
        description: "Mumbai is the heart of India's film industry, producing the largest number of movies in the world. The industry has significantly influenced Indian culture and entertainment globally."
      }
    ]
  },

  "manipur": {
    name: "Manipur",
    image: "/api/placeholder/800/400",
    description: "The jewel of India, known for its classical dance, polo sport origin, and scenic beauty.",
    history: "Manipur has a unique history with its own kingdom that maintained independence for many centuries. The Kangleipak kingdom, as it was originally known, has ancient connections with Southeast Asia. The region adopted Hinduism in the 18th century while maintaining its distinct culture. During World War II, Manipur became strategically important with the battles of Imphal and Kohima. The state merged with India in 1949 and has since struggled to maintain its cultural identity while integrating with the Indian union.",
    festivals: [
      {
        name: "Lai Haraoba",
        significance: "Ancient festival honoring local deities",
        description: "Traditional festival celebrating the creation of the world and honoring local deities called Lais.",
        celebration: "Ritualistic dances, traditional music, and ceremonies performed by maibas (priests) and maibis (priestesses). The festival connects people with their ancestral traditions and beliefs."
      },
      {
        name: "Yaoshang",
        significance: "Manipuri version of Holi",
        description: "Five-day festival celebrating the full moon of Phalguna month, similar to Holi but with local traditions.",
        celebration: "Traditional dances, sports competitions, and the famous Thabal Chongba (moonlight dance) where young people hold hands and dance in circles."
      }
    ],
    monuments: [
      {
        name: "Kangla Fort",
        location: "Imphal",
        bestSeason: "October to March",
        description: "Ancient seat of Manipur's rulers, sacred site with archaeological and religious significance."
      },
      {
        name: "Loktak Lake",
        location: "Bishnupur",
        bestSeason: "November to February",
        description: "Largest freshwater lake in Northeast India, famous for floating phumdis (vegetation)."
      },
      {
        name: "Shri Govindjee Temple",
        location: "Imphal",
        bestSeason: "October to March",
        description: "Important Vaishnavite temple showcasing Manipuri architecture and culture."
      },
      {
        name: "Keibul Lamjao National Park",
        location: "Bishnupur",
        bestSeason: "November to February",
        description: "Only floating national park in the world, home to endangered Sangai deer."
      },
      {
        name: "INA Memorial",
        location: "Imphal",
        bestSeason: "October to March",
        description: "Memorial dedicated to Indian National Army soldiers who fought in World War II."
      },
      {
        name: "Dzukou Valley",
        location: "Senapati",
        bestSeason: "June to September",
        description: "Valley of flowers on Manipur-Nagaland border, known for seasonal blooms."
      }
    ],
    culturalHighlights: [
      {
        category: "Dance",
        name: "Manipuri Classical Dance",
        description: "One of the eight classical dance forms of India, known for its graceful movements and spiritual themes. The dance form was developed in the temples and royal courts of Manipur."
      },
      {
        category: "Sports",
        name: "Polo Heritage",
        description: "Manipur is considered the birthplace of modern polo. The game, called 'Sagol Kangjei' locally, has been played here for centuries and was introduced to the world through British cavalry officers."
      },
      {
        category: "Culture",
        name: "Unique Traditions",
        description: "Manipur has a matrilineal society in some communities and maintains unique traditions including the famous women's market (Ima Keithel) run entirely by women for over 500 years."
      }
    ]
  },

  "meghalaya": {
    name: "Meghalaya",
    image: "/api/placeholder/800/400",
    description: "The abode of clouds, known for its matrilineal society, living root bridges, and wettest places on Earth.",
    history: "Meghalaya, formed in 1972, is one of India's youngest states. The region was traditionally inhabited by three main tribes: Khasi, Garo, and Jaintia, each with distinct cultures and languages. The area came under British influence but maintained much of its traditional governance through autonomous hill councils. The state is unique for its matrilineal society where women inherit property and family lineage is traced through mothers. Meghalaya has maintained its tribal character while adopting modern education and governance systems.",
    festivals: [
      {
        name: "Shad Suk Mynsiem",
        significance: "Khasi thanksgiving festival",
        description: "Most important festival of the Khasi community celebrating their gratitude to the Creator.",
        celebration: "Traditional dances performed by men and women in separate circles, wearing colorful traditional attire. The festival includes thanksgiving prayers, cultural performances, and community feasts."
      },
      {
        name: "Wangala",
        significance: "Garo harvest festival",
        description: "Post-harvest festival of the Garo community thanking the Sun God for abundant harvest.",
        celebration: "Traditional dances with drums and flutes, rice beer ceremonies, and thanksgiving rituals. Participants wear traditional costumes with feathered headgear and perform the famous hundred drums dance."
      }
    ],
    monuments: [
      {
        name: "Living Root Bridges",
        location: "Cherrapunji",
        bestSeason: "October to May",
        description: "Unique bioengineered bridges made from rubber tree roots, some over 500 years old."
      },
      {
        name: "Cherrapunji",
        location: "East Khasi Hills",
        bestSeason: "October to May",
        description: "One of the wettest places on Earth, known for dramatic landscapes and waterfalls."
      },
      {
        name: "Mawlynnong Village",
        location: "East Khasi Hills",
        bestSeason: "October to May",
        description: "Cleanest village in Asia, showcasing sustainable living and community cooperation."
      },
      {
        name: "Elephant Falls",
        location: "Shillong",
        bestSeason: "October to May",
        description: "Three-tiered waterfall near Shillong, popular for its scenic beauty."
      },
      {
        name: "Umiam Lake",
        location: "Ri-Bhoi",
        bestSeason: "October to May",
        description: "Artificial lake created by damming the Umiam River, popular for water sports."
      },
      {
        name: "Dawki River",
        location: "West Jaintia Hills",
        bestSeason: "November to May",
        description: "Crystal clear river at India-Bangladesh border, famous for transparent waters."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Matrilineal Society",
        description: "Unique social system where lineage and inheritance pass through women. The youngest daughter inherits the family property and takes care of parents, creating a society where women have significant social status."
      },
      {
        category: "Environment",
        name: "Sacred Groves",
        description: "Traditional conservation practice where communities protect forest patches as sacred sites. These groves preserve biodiversity and represent the indigenous knowledge of environmental conservation."
      },
      {
        category: "Music",
        name: "Contemporary Music Scene",
        description: "Shillong is known as the 'Rock Capital of India' with a vibrant music scene. The state has produced many renowned musicians and bands, blending Western and traditional music forms."
      }
    ]
  },

  "mizoram": {
    name: "Mizoram",
    image: "/api/placeholder/800/400",
    description: "Land of the hill people, known for its bamboo forests, tribal culture, and high literacy rates.",
    history: "Mizoram's history is closely tied to the Mizo people who migrated from the Tibeto-Burman region. The area was largely isolated until British rule in the late 19th century. The region witnessed significant unrest and insurgency movements in the mid-20th century before achieving statehood in 1987. The Mizo Peace Accord of 1986 ended two decades of insurgency and brought peace to the region. Mizoram has since developed into one of India's most literate and peaceful states.",
    festivals: [
      {
        name: "Chapchar Kut",
        significance: "Spring festival celebrating bamboo flowering",
        description: "Most important festival of Mizoram celebrating the arrival of spring and bamboo flowering.",
        celebration: "Traditional Cheraw (bamboo dance), cultural performances, community feasts, and traditional sports. People wear colorful traditional attire and participate in various cultural activities."
      },
      {
        name: "Pawl Kut",
        significance: "Harvest festival celebrating abundance",
        description: "Post-harvest festival celebrating the successful completion of agricultural activities.",
        celebration: "Traditional dances, folk songs, rice beer ceremonies, and thanksgiving rituals. Communities come together to celebrate the harvest and share their abundance."
      }
    ],
    monuments: [
      {
        name: "Reiek Tlang",
        location: "Mamit",
        bestSeason: "October to March",
        description: "Highest peak in Mizoram offering panoramic views of the surrounding hills."
      },
      {
        name: "Phawngpui Blue Mountain",
        location: "Saiha",
        bestSeason: "October to April",
        description: "Highest peak in Mizoram and home to rare orchids and rhododendrons."
      },
      {
        name: "Champhai",
        location: "Champhai",
        bestSeason: "October to March",
        description: "Border town known as the 'Rice Bowl of Mizoram' with scenic landscapes."
      },
      {
        name: "Aizawl",
        location: "Aizawl",
        bestSeason: "October to March",
        description: "Capital city built on ridges, showcasing modern Mizo urban culture."
      },
      {
        name: "Murlen National Park",
        location: "Champhai",
        bestSeason: "November to March",
        description: "National park preserving the state's biodiversity and mountain ecosystems."
      },
      {
        name: "Vantawng Falls",
        location: "Serchhip",
        bestSeason: "October to March",
        description: "Tallest waterfall in Mizoram, cascading from a height of 750 feet."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Mizo Society",
        description: "Highly organized society with strong community bonds and social values. The concept of 'Tlawmngaihna' (selfless service) is central to Mizo culture, emphasizing helping others without expectation of reward."
      },
      {
        category: "Art",
        name: "Traditional Crafts",
        description: "Skilled in bamboo and cane work, handloom weaving, and traditional jewelry making. Puan (traditional textile) weaving is particularly significant, with different patterns representing various occasions and social status."
      },
      {
        category: "Music",
        name: "Folk Music and Dance",
        description: "Rich tradition of folk music and dance including the famous Cheraw (bamboo dance). Traditional instruments like drums, gongs, and bamboo flutes accompany various cultural performances."
      }
    ]
  },

  "nagaland": {
    name: "Nagaland",
    image: "/api/placeholder/800/400",
    description: "Land of festivals, known for its warrior tribes, vibrant culture, and the hornbill festival.",
    history: "Nagaland has a unique history of independent tribal kingdoms that fiercely resisted outside rule. The British colonial administration finally established control in the late 19th century after years of conflict. The region witnessed significant upheaval during World War II and later during the independence movement. Nagaland became a state in 1963 after years of insurgency and political negotiations. The state has since worked towards preserving its tribal identity while integrating with the Indian union.",
    festivals: [
      {
        name: "Hornbill Festival",
        significance: "Festival of festivals showcasing Naga culture",
        description: "Premier festival showcasing the diverse cultures of all Naga tribes in one venue.",
        celebration: "Traditional dances, folk songs, indigenous games, crafts exhibitions, and local cuisine. The festival has become a major cultural event attracting visitors from around the world."
      },
      {
        name: "Aoling Festival",
        significance: "Konyak tribe's most important festival",
        description: "Six-day festival of the Konyak tribe marking the arrival of spring and beginning of agricultural activities.",
        celebration: "Traditional rituals, community feasts, folk dances, and cultural exchanges. The festival strengthens tribal bonds and preserves ancient traditions."
      }
    ],
    monuments: [
      {
        name: "Kohima War Cemetery",
        location: "Kohima",
        bestSeason: "October to March",
        description: "Memorial dedicated to soldiers who died in the Battle of Kohima during World War II."
      },
      {
        name: "Dzukou Valley",
        location: "Kohima",
        bestSeason: "June to September",
        description: "Valley of flowers on Nagaland-Manipur border, known for seasonal blooms."
      },
      {
        name: "Japfu Peak",
        location: "Kohima",
        bestSeason: "October to March",
        description: "Second highest peak in Nagaland offering trekking opportunities and scenic views."
      },
      {
        name: "Mon District",
        location: "Mon",
        bestSeason: "October to March",
        description: "Home to the Konyak tribe, known for traditional headhunting culture and crafts."
      },
      {
        name: "Longwa Village",
        location: "Mon",
        bestSeason: "October to March",
        description: "Village straddling India-Myanmar border, showcasing traditional Konyak culture."
      },
      {
        name: "Ntangki National Park",
        location: "Peren",
        bestSeason: "November to March",
        description: "National park preserving the region's biodiversity and wildlife."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Tribal Diversity",
        description: "Home to 16 major tribes, each with distinct languages, customs, and traditions. The state has over 60 dialects and maintains strong tribal identities while promoting unity."
      },
      {
        category: "Art",
        name: "Traditional Crafts",
        description: "Excellent woodcarving, weaving, pottery, and metalwork. Traditional Naga shawls, wood carvings, and bamboo crafts are highly valued for their intricate designs and cultural significance."
      },
      {
        category: "Food",
        name: "Naga Cuisine",
        description: "Unique cuisine featuring smoked and fermented foods, bamboo shoot preparations, and local herbs. The cuisine is known for its simplicity, use of local ingredients, and distinctive flavors."
      }
    ]
  },

  "odisha": {
    name: "Odisha",
    image: "/api/placeholder/800/400",
    description: "The land of Lord Jagannath, known for its ancient temples, classical dance, and maritime heritage.",
    history: "Odisha has a glorious history dating back to ancient times when it was known as Kalinga. The region is famous for the Kalinga War fought by Emperor Ashoka, which led to his conversion to Buddhism. The state was ruled by various dynasties including the Eastern Gangas, Gajapatis, and later the Marathas and British. Odisha has been a center of art, culture, and religion with magnificent temples like the Sun Temple at Konark. The state has maintained its distinct Odia culture while contributing significantly to Indian classical arts.",
    festivals: [
      {
        name: "Jagannath Rath Yatra",
        significance: "Grand chariot festival of Lord Jagannath",
        description: "One of the largest religious festivals in the world, celebrating Lord Jagannath's annual journey.",
        celebration: "Massive wooden chariots carrying deities are pulled by thousands of devotees through the streets of Puri. The festival attracts millions of pilgrims and is a spectacular display of devotion."
      },
      {
        name: "Konark Dance Festival",
        significance: "Celebration of classical Indian dance",
        description: "Annual festival showcasing various forms of Indian classical dance against the backdrop of the Sun Temple.",
        celebration: "Renowned artists perform various classical dance forms including Odissi, Bharatanatyam, Kathak, and others. The festival celebrates India's rich dance heritage."
      }
    ],
    monuments: [
      {
        name: "Konark Sun Temple",
        location: "Puri",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, magnificent 13th-century temple dedicated to the Sun God."
      },
      {
        name: "Jagannath Temple",
        location: "Puri",
        bestSeason: "October to March",
        description: "One of the four Char Dham pilgrimage sites, dedicated to Lord Jagannath."
      },
      {
        name: "Lingaraj Temple",
        location: "Bhubaneswar",
        bestSeason: "October to March",
        description: "Ancient temple dedicated to Lord Shiva, masterpiece of Kalinga architecture."
      },
      {
        name: "Udayagiri and Khandagiri Caves",
        location: "Bhubaneswar",
        bestSeason: "October to March",
        description: "Ancient Jain caves dating back to 2nd century BCE with intricate carvings."
      },
      {
        name: "Chilika Lake",
        location: "Puri",
        bestSeason: "November to February",
        description: "Largest coastal lagoon in India, haven for migratory birds and biodiversity."
      },
      {
        name: "Simlipal National Park",
        location: "Mayurbhanj",
        bestSeason: "November to June",
        description: "Tiger reserve and biosphere reserve known for its biodiversity and waterfalls."
      },
      {
        name: "Dhauli Shanti Stupa",
        location: "Bhubaneswar",
        bestSeason: "October to March",
        description: "Peace pagoda built at the site of the famous Kalinga War fought by Emperor Ashoka."
      }
    ],
    culturalHighlights: [
      {
        category: "Dance",
        name: "Odissi",
        description: "One of the eight classical dance forms of India, originated in the temples of Odisha. Known for its graceful movements, sculpturesque poses, and spiritual themes depicting stories from Hindu mythology."
      },
      {
        category: "Art",
        name: "Pattachitra Paintings",
        description: "Traditional cloth-based scroll painting depicting mythological narratives, religious themes, and folk tales. These intricate paintings use natural colors and traditional techniques passed down through generations."
      },
      {
        category: "Food",
        name: "Odia Cuisine",
        description: "Simple yet flavorful cuisine emphasizing rice, fish, and vegetables. Famous dishes include dalma, pakhala, rasgulla (originated in Odisha), and various seafood preparations reflecting the state's coastal heritage."
      },
      {
        category: "Crafts",
        name: "Stone Carving",
        description: "Excellent tradition of stone carving seen in temples and monuments. Artisans continue the ancient tradition of creating intricate sculptures and architectural elements using traditional techniques."
      }
    ]
  },

  "punjab": {
    name: "Punjab",
    image: "/api/placeholder/800/400",
    description: "The land of five rivers, known for its fertile plains, vibrant culture, and Sikh heritage.",
    history: "Punjab, meaning 'land of five rivers,' has been a crossroads of civilizations for millennia. The region witnessed the rise of Sikhism under Guru Nanak and later Sikh rulers who established a powerful kingdom. The area was ruled by various empires including the Mughals, and later Maharaja Ranjit Singh created the Sikh Empire. Punjab was partitioned in 1947, leading to massive population exchange and trauma. The state has since emerged as India's agricultural powerhouse and maintains its distinct Punjabi and Sikh culture.",
    festivals: [
      {
        name: "Baisakhi",
        significance: "Harvest festival and Sikh New Year",
        description: "Most important festival celebrating the wheat harvest and commemorating the formation of Khalsa.",
        celebration: "Gurdwaras organize special prayers, langars (community meals), and cultural programs. People perform Bhangra and Gidda dances, and the festival marks the beginning of the agricultural new year."
      },
      {
        name: "Guru Nanak Jayanti",
        significance: "Birthday celebration of Guru Nanak",
        description: "Most sacred festival for Sikhs, celebrating the birth of the first Sikh Guru.",
        celebration: "Nagar Kirtan (religious processions), continuous reading of Guru Granth Sahib, langar service, and community prayers. Gurdwaras are illuminated and decorated for the occasion."
      }
    ],
    monuments: [
      {
        name: "Golden Temple",
        location: "Amritsar",
        bestSeason: "October to March",
        description: "Holiest Gurdwara and spiritual center of Sikhism, known for its golden architecture."
      },
      {
        name: "Jallianwala Bagh",
        location: "Amritsar",
        bestSeason: "October to March",
        description: "Memorial site of the tragic 1919 massacre, symbol of India's struggle for independence."
      },
      {
        name: "Anandpur Sahib",
        location: "Rupnagar",
        bestSeason: "October to March",
        description: "Holy city where Khalsa was founded, important pilgrimage site for Sikhs."
      },
      {
        name: "Qila Mubarak",
        location: "Patiala",
        bestSeason: "October to March",
        description: "Historic fort complex showcasing Punjabi architecture and royal heritage."
      },
      {
        name: "Wagah Border",
        location: "Amritsar",
        bestSeason: "October to March",
        description: "International border between India and Pakistan, famous for daily flag ceremony."
      },
      {
        name: "Fatehgarh Sahib",
        location: "Fatehgarh Sahib",
        bestSeason: "October to March",
        description: "Historic gurdwara commemorating the martyrdom of Guru Gobind Singh's sons."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Sikh Heritage",
        description: "Punjab is the spiritual homeland of Sikhism with numerous gurdwaras, including the Golden Temple. The state maintains strong Sikh traditions of service, equality, and community kitchen (langar) culture."
      },
      {
        category: "Agriculture",
        name: "Green Revolution",
        description: "Punjab led India's Green Revolution, transforming from a food-deficit to surplus state. The state is known for wheat and rice production and modern agricultural practices."
      },
      {
        category: "Music",
        name: "Punjabi Music",
        description: "Vibrant music tradition including folk songs, bhangra, and modern Punjabi pop. The state has produced numerous musicians who have gained international recognition."
      },
      {
        category: "Food",
        name: "Punjabi Cuisine",
        description: "Rich, flavorful cuisine featuring dairy products, wheat, and vegetables. Famous dishes include makki di roti with sarson da saag, lassi, and various dal preparations."
      }
    ]
  },

  "rajasthan": {
    name: "Rajasthan",
    image: "/api/placeholder/800/400",
    description: "The 'Land of Kings', Rajasthan is synonymous with royalty, valor, and magnificent palaces that tell tales of a glorious past.",
    history: "Rajasthan, literally meaning 'Land of Kings', has a rich and tumultuous history spanning over 1,500 years. The region was ruled by various Rajput clans including the Chauhans, Rathores, Sisodias, and Kachwahas. These warrior clans built magnificent forts and palaces that still stand today as testimony to their architectural prowess and military might. The state witnessed the rise and fall of several kingdoms, including Mewar, Marwar, Amber, and Bikaner. The Rajputs were known for their chivalry, honor, and fierce independence, often choosing death over dishonor. The region also saw the influence of Mughal rulers, who left their mark on the architecture and culture. The princely states of Rajasthan played a significant role in India's freedom struggle, with many rulers supporting the independence movement.",
    festivals: [
      {
        name: "Teej",
        significance: "Celebration of monsoon and marital bliss",
        description: "Teej is one of the most significant festivals for Rajasthani women, celebrating the arrival of monsoon and honoring Goddess Parvati.",
        celebration: "Women dress in vibrant green and red attire, apply intricate henna designs, and participate in traditional folk dances. Swings are decorated with flowers and women enjoy swinging while singing folk songs. Special delicacies like ghewar and feeni are prepared."
      },
      {
        name: "Pushkar Camel Fair",
        significance: "World's largest camel trading festival",
        description: "This annual fair transforms the quiet town of Pushkar into a vibrant carnival of colors, sounds, and activities.",
        celebration: "Camel races, folk performances, traditional competitions like longest mustache and turban tying contests are held. The fair combines religious pilgrimage with commercial activities, creating a unique cultural spectacle."
      },
      {
        name: "Gangaur",
        significance: "Worship of Goddess Gauri for marital happiness",
        description: "An 18-day festival celebrated by women for the well-being of their husbands and to seek blessings for a happy married life.",
        celebration: "Women create beautiful clay idols of Goddess Gauri, carry kalash (water pots) on their heads in processions, and perform traditional rituals. The festival culminates with immersion of the idol in water bodies."
      }
    ],
    monuments: [
      {
        name: "Amber Fort",
        location: "Jaipur",
        bestSeason: "October to March",
        description: "A magnificent fort-palace complex built with red sandstone and marble, showcasing the fusion of Hindu and Mughal architecture."
      },
      {
        name: "Hawa Mahal",
        location: "Jaipur",
        bestSeason: "October to March",
        description: "The iconic 'Palace of Winds' with its distinctive honeycomb structure and 953 small windows designed for royal ladies to observe street life."
      },
      {
        name: "Mehrangarh Fort",
        location: "Jodhpur",
        bestSeason: "October to March",
        description: "One of India's largest forts, perched on a rocky hill 400 feet above Jodhpur, offering spectacular views of the 'Blue City'."
      },
      {
        name: "City Palace",
        location: "Udaipur",
        bestSeason: "September to March",
        description: "A majestic palace complex on Lake Pichola's banks, blending Rajasthani and Mughal architecture with beautiful courtyards and gardens."
      },
      {
        name: "Jaisalmer Fort",
        location: "Jaisalmer",
        bestSeason: "November to February",
        description: "A living fort made of golden sandstone, still inhabited by thousands of people, earning it the nickname 'Golden Fort'."
      },
      {
        name: "Chittorgarh Fort",
        location: "Chittorgarh",
        bestSeason: "October to March",
        description: "The largest fort in India, symbolizing Rajput pride and sacrifice, with numerous palaces, temples, and towers within its walls."
      },
      {
        name: "Dilwara Temples",
        location: "Mount Abu",
        bestSeason: "November to February",
        description: "Exquisite Jain temples known for their stunning marble carvings and intricate architectural details, considered masterpieces of craftsmanship."
      }
    ],
    culturalHighlights: [
      {
        category: "Food",
        name: "Dal Baati Churma",
        description: "The quintessential Rajasthani dish consisting of baked wheat balls (baati) served with lentil curry (dal) and sweet crumbled wheat (churma). This hearty meal represents the ingenuity of desert cooking, designed to last long without spoiling in the arid climate."
      },
      {
        category: "Art",
        name: "Miniature Paintings",
        description: "Rajasthan is renowned for its miniature painting traditions, including the Mewar, Marwar, and Hadoti schools. These intricate paintings depict royal court scenes, religious themes, and folk tales using natural pigments and gold leaf on paper and cloth."
      },
      {
        category: "Music",
        name: "Folk Music Traditions",
        description: "Rich tradition of folk music performed by communities like the Manganiyars and Langas. Instruments like the rawanhatha, kamaycha, and khartal create soulful melodies that narrate tales of love, valor, and devotion, often performed around campfires in the desert."
      },
      {
        category: "Dance",
        name: "Ghoomar Dance",
        description: "A traditional folk dance performed by women in flowing ghagras (long skirts) that create beautiful circular patterns. Originally performed by the Bhil tribe, it was later adopted by the royal Rajput women and is now a symbol of Rajasthani culture."
      },
      {
        category: "Traditions",
        name: "Puppet Shows (Kathputli)",
        description: "Traditional string puppet performances that narrate stories of heroic deeds, love tales, and historical events. The colorful wooden puppets are manipulated by skilled artists while folk music plays in the background, creating an engaging entertainment form."
      }
    ]
  },

  "sikkim": {
    name: "Sikkim",
    image: "/api/placeholder/800/400",
    description: "The mystical mountain kingdom, known for its Buddhist monasteries, stunning Himalayan views, and organic farming.",
    history: "Sikkim was an independent kingdom ruled by the Namgyal dynasty from 1642 until 1975. The kingdom was established by Phuntsog Namgyal and remained isolated from the outside world for centuries. British influence began in the 19th century, and later India became responsible for Sikkim's defense and external affairs. After political upheaval and a referendum, Sikkim joined India as its 22nd state in 1975. The state has successfully preserved its Buddhist culture while modernizing and becoming India's first organic state.",
    festivals: [
      {
        name: "Losar",
        significance: "Tibetan New Year celebration",
        description: "Most important festival in Sikkim, marking the beginning of the Tibetan lunar new year.",
        celebration: "Monasteries conduct special prayers, traditional cham dances are performed, and families prepare special foods like khapse. The festival includes traditional archery competitions and cultural programs."
      },
      {
        name: "Saga Dawa",
        significance: "Celebration of Buddha's enlightenment",
        description: "Sacred month commemorating Buddha's birth, enlightenment, and death (parinirvana).",
        celebration: "Pilgrimages to sacred sites, prayer flag hoisting, religious discourses, and community prayers. Devotees accumulate merit through acts of charity and spiritual practices."
      }
    ],
    monuments: [
      {
        name: "Rumtek Monastery",
        location: "East Sikkim",
        bestSeason: "March to May, October to December",
        description: "Most important monastery in Sikkim, seat of the Karmapa lineage of Tibetan Buddhism."
      },
      {
        name: "Tsomgo Lake",
        location: "East Sikkim",
        bestSeason: "April to June, September to December",
        description: "Sacred glacial lake at 12,400 feet, considered holy by local people."
      },
      {
        name: "Nathula Pass",
        location: "East Sikkim",
        bestSeason: "May to October",
        description: "Historic trade route between India and China, part of the ancient Silk Road."
      },
      {
        name: "Pemayangtse Monastery",
        location: "West Sikkim",
        bestSeason: "March to May, October to December",
        description: "Second oldest monastery in Sikkim with rich collection of Buddhist artifacts."
      },
      {
        name: "Yuksom",
        location: "West Sikkim",
        bestSeason: "March to May, October to December",
        description: "First capital of Sikkim and base for Kanchenjunga trek, historically significant town."
      },
      {
        name: "Gurudongmar Lake",
        location: "North Sikkim",
        bestSeason: "May to October",
        description: "Sacred high-altitude lake at 17,800 feet, one of the highest lakes in the world."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Buddhist Heritage",
        description: "Rich Buddhist culture with numerous monasteries, prayer flags, and traditional practices. The state maintains strong connections with Tibetan Buddhism and serves as an important center for Buddhist learning."
      },
      {
        category: "Environment",
        name: "Organic State",
        description: "First fully organic state in India, committed to sustainable agriculture and environmental conservation. The state has banned chemical fertilizers and pesticides, promoting traditional farming methods."
      },
      {
        category: "Food",
        name: "Sikkimese Cuisine",
        description: "Unique blend of Nepali, Tibetan, and Indian influences featuring momos, thukpa, gundruk, and sel roti. The cuisine uses local ingredients and traditional cooking methods."
      }
    ]
  },

  "tamil-nadu": {
    name: "Tamil Nadu",
    image: "/api/placeholder/800/400",
    description: "The land of ancient Dravidian culture, magnificent temples, and classical arts.",
    history: "Tamil Nadu has one of the oldest civilizations in the world, with evidence of human habitation dating back to prehistoric times. The region was ruled by great Dravidian kingdoms including the Cholas, Cheras, and Pandyas. The Chola Empire was particularly influential, with maritime trade extending to Southeast Asia. The state has a rich tradition of literature, art, and architecture. During colonial times, Madras (now Chennai) became an important administrative center. Tamil Nadu has maintained its distinct Tamil culture while becoming a major industrial and technological hub.",
    festivals: [
      {
        name: "Pongal",
        significance: "Harvest festival thanking nature",
        description: "Most important festival in Tamil Nadu, celebrating the harvest season and honoring the sun, earth, and cattle.",
        celebration: "Traditional kolam (rangoli) designs, boiling of new rice with milk and jaggery, decorating cattle with bells and garlands, and various cultural activities spanning four days."
      },
      {
        name: "Mahamaham",
        significance: "Sacred bathing festival",
        description: "Once in 12 years festival held in Kumbakonam when devotees take holy dips in the sacred tank.",
        celebration: "Millions of pilgrims gather to bathe in the Mahamaham tank, believing it will wash away their sins. Elaborate religious ceremonies and cultural programs accompany the festival."
      }
    ],
    monuments: [
      {
        name: "Brihadeeswarar Temple",
        location: "Thanjavur",
        bestSeason: "November to March",
        description: "UNESCO World Heritage site, masterpiece of Chola architecture with 1000-year-old granite tower."
      },
      {
        name: "Meenakshi Temple",
        location: "Madurai",
        bestSeason: "October to March",
        description: "Magnificent temple complex dedicated to goddess Meenakshi with intricately carved gopurams."
      },
      {
        name: "Shore Temple",
        location: "Mahabalipuram",
        bestSeason: "November to February",
        description: "UNESCO World Heritage site, 8th-century temple overlooking the Bay of Bengal."
      },
      {
        name: "Nilgiri Mountain Railway",
        location: "Ooty",
        bestSeason: "April to June, September to November",
        description: "UNESCO World Heritage toy train journey through picturesque Nilgiri hills."
      },
      {
        name: "Rameswaram Temple",
        location: "Ramanathapuram",
        bestSeason: "October to April",
        description: "Sacred temple and pilgrimage site with the longest temple corridor in the world."
      },
      {
        name: "Kanyakumari",
        location: "Kanyakumari",
        bestSeason: "October to March",
        description: "Southernmost tip of India where three oceans meet, significant pilgrimage destination."
      },
      {
        name: "Chettinad",
        location: "Sivaganga",
        bestSeason: "November to March",
        description: "Region known for unique architecture, spicy cuisine, and wealthy merchant heritage."
      }
    ],
    culturalHighlights: [
      {
        category: "Dance",
        name: "Bharatanatyam",
        description: "One of the oldest classical dance forms of India, originated in Tamil Nadu. Known for its precise movements, expressions, and spiritual themes, it was traditionally performed in temples."
      },
      {
        category: "Music",
        name: "Carnatic Music",
        description: "Classical music tradition of South India with Tamil Nadu being a major center. The state has produced legendary composers like Tyagaraja, Muthuswami Dikshitar, and Syama Sastri."
      },
      {
        category: "Art",
        name: "Bronze Sculpture",
        description: "Exquisite tradition of bronze casting, particularly Chola bronzes which are considered masterpieces of world art. The lost-wax technique produces intricate sculptures of deities."
      },
      {
        category: "Food",
        name: "Tamil Cuisine",
        description: "Rich culinary tradition featuring rice, lentils, spices, and coconut. Famous dishes include sambar, rasam, idli, dosa, and various Chettinad specialties known for their fiery flavors."
      },
      {
        category: "Literature",
        name: "Tamil Literature",
        description: "One of the oldest literatures in the world with classical works like Tolkappiyam and Sangam poetry. The language has a rich tradition of poetry, philosophy, and devotional literature."
      }
    ]
  },

  "telangana": {
    name: "Telangana",
    image: "/api/placeholder/800/400",
    description: "The youngest state of India, known for its rich history, technology hub Hyderabad, and vibrant culture.",
    history: "Telangana has a rich history dating back to ancient times when it was part of various kingdoms including the Satavahanas, Kakatiyas, and later the Qutb Shahi dynasty who built Hyderabad. The region was ruled by the Nizams of Hyderabad until independence. After being part of Andhra Pradesh for 58 years, Telangana became India's 29th state in 2014 following a prolonged political movement. The state has rapidly developed into a major IT hub while preserving its cultural heritage.",
    festivals: [
      {
        name: "Bonalu",
        significance: "Goddess festival honoring Mahakali",
        description: "Annual festival dedicated to goddess Mahakali, celebrated with great devotion in Telangana.",
        celebration: "Women carry decorated pots (bonam) with cooked rice, jaggery, and curd to temples. Traditional dances, processions, and oracle predictions characterize the festival."
      },
      {
        name: "Sammakka Saralamma Jatara",
        significance: "Tribal festival honoring folk goddesses",
        description: "Largest tribal festival in India, held once every two years honoring tribal goddesses.",
        celebration: "Millions of devotees gather in the forest to worship at the shrine. The festival showcases tribal culture and traditions with no formal priests conducting rituals."
      }
    ],
    monuments: [
      {
        name: "Charminar",
        location: "Hyderabad",
        bestSeason: "October to March",
        description: "Iconic monument and symbol of Hyderabad built in 1591 by Sultan Muhammad Quli Qutb Shah."
      },
      {
        name: "Golconda Fort",
        location: "Hyderabad",
        bestSeason: "October to March",
        description: "Historic fort complex famous for its acoustic system and diamond mines."
      },
      {
        name: "Ramappa Temple",
        location: "Warangal",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, 13th-century temple showcasing Kakatiya architecture."
      },
      {
        name: "Thousand Pillar Temple",
        location: "Warangal",
        bestSeason: "October to March",
        description: "Magnificent temple built by Kakatiya dynasty with intricate stone carving."
      },
      {
        name: "Bhadrachalam Temple",
        location: "Bhadradri Kothagudem",
        bestSeason: "October to March",
        description: "Sacred temple dedicated to Lord Rama, important pilgrimage site."
      },
      {
        name: "Nagarjuna Sagar",
        location: "Nalgonda",
        bestSeason: "October to March",
        description: "Large dam and reservoir with ancient Buddhist sites on Nagarjunakonda island."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Telangana Identity",
        description: "Distinct regional culture with unique dialects, folk traditions, and customs. The state takes pride in its separate identity while maintaining connections with broader Telugu culture."
      },
      {
        category: "Technology",
        name: "HITEC City",
        description: "Hyderabad has emerged as a major IT hub known as 'Cyberabad,' housing numerous multinational companies and contributing significantly to India's IT industry."
      },
      {
        category: "Food",
        name: "Hyderabadi Cuisine",
        description: "Rich culinary tradition blending Mughlai and local flavors. Famous for Hyderabadi biryani, haleem, kebabs, and sweets like double ka meetha and qubani ka meetha."
      }
    ]
  },

  "tripura": {
    name: "Tripura",
    image: "/api/placeholder/800/400",
    description: "Land of diverse tribes, ancient temples, and rich cultural heritage in Northeast India.",
    history: "Tripura has a unique history as an independent kingdom ruled by the Manikya dynasty for over 500 years. The kingdom maintained its independence until it merged with India in 1949. The region has diverse tribal communities and a significant Bengali population. The state witnessed political unrest and insurgency movements but has achieved peace and development in recent decades. Tripura has preserved its tribal heritage while integrating with mainstream Indian culture.",
    festivals: [
      {
        name: "Garia Puja",
        significance: "Tribal festival worshipping Garia deity",
        description: "Most important festival of Tripuri tribes, celebrating the harvest and honoring Garia, the deity of strength.",
        celebration: "Traditional dances, folk songs, sacrifice of fowls and pigs, rice beer ceremonies, and community feasts. The festival strengthens tribal bonds and preserves ancient traditions."
      },
      {
        name: "Kharchi Puja",
        significance: "Royal festival of fourteen deities",
        description: "Grand festival celebrating fourteen deities worshipped by the erstwhile royal family.",
        celebration: "Seven-day festival with elaborate rituals, cultural programs, and fair. Devotees from across the region participate in this celebration of Tripura's royal heritage."
      }
    ],
    monuments: [
      {
        name: "Ujjayanta Palace",
        location: "Agartala",
        bestSeason: "October to March",
        description: "Former royal palace, now museum showcasing Tripura's history and culture."
      },
      {
        name: "Chaturdasha Temple",
        location: "Agartala",
        bestSeason: "October to March",
        description: "Temple complex housing fourteen deities, site of the famous Kharchi Puja."
      },
      {
        name: "Sepahijala Wildlife Sanctuary",
        location: "Sepahijala",
        bestSeason: "October to March",
        description: "Wildlife sanctuary known for spectacled monkeys and clouded leopards."
      },
      {
        name: "Jampui Hills",
        location: "North Tripura",
        bestSeason: "October to March",
        description: "Hill range known for orange cultivation and scenic beauty."
      },
      {
        name: "Tripura Sundari Temple",
        location: "Udaipur",
        bestSeason: "October to March",
        description: "Ancient temple dedicated to goddess Tripura Sundari, one of the 51 Shakti Peethas."
      },
      {
        name: "Neermahal",
        location: "Udaipur",
        bestSeason: "October to March",
        description: "Water palace built in the middle of Rudrasagar Lake, showcasing Indo-Saracenic architecture."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Tribal Heritage",
        description: "Home to 19 tribal communities including Tripuri, Reang, Jamatia, and Chakma tribes. Each community has distinct languages, customs, and traditional practices that are actively preserved."
      },
      {
        category: "Art",
        name: "Traditional Crafts",
        description: "Rich tradition of bamboo and cane work, handloom weaving, and traditional jewelry. Tripuri women are skilled in weaving colorful textiles with traditional patterns."
      },
      {
        category: "Food",
        name: "Tripuri Cuisine",
        description: "Simple cuisine featuring rice, fish, vegetables, and bamboo shoots. Popular dishes include muya awandru (fermented fish chutney), wahan mosdeng (pork with onions), and various preparations with local herbs."
      }
    ]
  },

  "uttar-pradesh": {
    name: "Uttar Pradesh",
    image: "/api/placeholder/800/400",
    description: "The heartland of India, home to the Taj Mahal, sacred Ganges, and diverse cultural heritage.",
    history: "Uttar Pradesh, India's most populous state, has been central to Indian civilization for millennia. The region has been ruled by various dynasties including the Mauryas, Guptas, Delhi Sultanate, and Mughals. It witnessed the rise of great empires and cultural movements. The state is home to several holy cities along the Ganges and played a crucial role in India's independence movement. Many Prime Ministers of India have come from this state, earning it the nickname 'political heartland of India.'",
    festivals: [
      {
        name: "Kumbh Mela",
        significance: "World's largest religious gathering",
        description: "Massive Hindu pilgrimage held every 12 years in Prayagraj (Allahabad), rotating between four cities.",
        celebration: "Millions of pilgrims gather to bathe in the sacred confluence of Ganges, Yamuna, and mythical Saraswati rivers. The event includes religious discourses, cultural programs, and spiritual activities."
      },
      {
        name: "Dev Deepawali",
        significance: "Festival of lights in Varanasi",
        description: "Celebrated 15 days after Diwali when the ghats of Varanasi are illuminated with thousands of diyas.",
        celebration: "The entire riverfront comes alive with lights, cultural performances, and spiritual activities. Devotees believe that gods descend to earth on this day to bathe in the Ganges."
      }
    ],
    monuments: [
      {
        name: "Taj Mahal",
        location: "Agra",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, symbol of eternal love and masterpiece of Mughal architecture."
      },
      {
        name: "Varanasi Ghats",
        location: "Varanasi",
        bestSeason: "October to March",
        description: "Sacred steps leading to the Ganges, where pilgrims perform rituals and ceremonies."
      },
      {
        name: "Fatehpur Sikri",
        location: "Agra",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, former Mughal capital showcasing Indo-Islamic architecture."
      },
      {
        name: "Sarnath",
        location: "Varanasi",
        bestSeason: "October to March",
        description: "Sacred Buddhist site where Buddha delivered his first sermon after enlightenment."
      },
      {
        name: "Ayodhya",
        location: "Ayodhya",
        bestSeason: "October to March",
        description: "Sacred city believed to be the birthplace of Lord Rama, important pilgrimage destination."
      },
      {
        name: "Mathura-Vrindavan",
        location: "Mathura",
        bestSeason: "October to March",
        description: "Birthplace and childhood abode of Lord Krishna, major pilgrimage centers."
      },
      {
        name: "Allahabad Fort",
        location: "Prayagraj",
        bestSeason: "October to March",
        description: "Mughal fort built by Emperor Akbar, situated at the confluence of holy rivers."
      }
    ],
    culturalHighlights: [
      {
        category: "Religion",
        name: "Spiritual Heritage",
        description: "Home to some of Hinduism's holiest cities including Varanasi, Mathura, Ayodhya, and Prayagraj. The state is central to Hindu pilgrimage traditions and spiritual practices."
      },
      {
        category: "Art",
        name: "Classical Arts",
        description: "Rich tradition of classical music and dance including Kathak dance form, Hindustani classical music, and various folk art forms. The state has produced many renowned artists and musicians."
      },
      {
        category: "Food",
        name: "Awadhi Cuisine",
        description: "Refined cuisine from the Awadh region featuring elaborate preparations like biryanis, kebabs, and kormas. The cuisine reflects Mughal influences and sophisticated cooking techniques."
      },
      {
        category: "Language",
        name: "Hindi Literature",
        description: "Birthplace of modern Hindi literature with legendary writers like Munshi Premchand, Harivansh Rai Bachchan, and Bharatendu Harishchandra contributing to Indian literature."
      }
    ]
  },

  "uttarakhand": {
    name: "Uttarakhand",
    image: "/api/placeholder/800/400",
    description: "Dev Bhoomi - the land of gods, known for sacred pilgrimage sites, snow-capped peaks, and spiritual heritage.",
    history: "Uttarakhand, carved out of Uttar Pradesh in 2000, is known as 'Dev Bhoomi' (Land of Gods) due to its numerous temples and pilgrimage sites. The region has been significant in Hindu mythology and spirituality for millennia. The area was ruled by various dynasties including the Katyuris and later the Gorkhas and British. The state is home to the sources of sacred rivers Ganges and Yamuna. It has been a center for spiritual learning and yoga traditions.",
    festivals: [
      {
        name: "Nanda Devi Raj Jat Yatra",
        significance: "Sacred pilgrimage honoring goddess Nanda Devi",
        description: "Once in 12 years pilgrimage to honor the patron goddess of Uttarakhand.",
        celebration: "Devotees carry a four-horned ram and sacred umbrella on a 280-km journey through the Himalayas. The pilgrimage involves various rituals and traditional ceremonies."
      },
      {
        name: "Kumbh Mela",
        significance: "Holy gathering at Haridwar",
        description: "Major religious festival held every 12 years in Haridwar, one of the four Kumbh sites.",
        celebration: "Millions of pilgrims gather to bathe in the sacred Ganges, believing it washes away sins. The event includes religious discourses and cultural activities."
      }
    ],
    monuments: [
      {
        name: "Kedarnath Temple",
        location: "Rudraprayag",
        bestSeason: "May to June, September to October",
        description: "One of the twelve Jyotirlingas, sacred temple dedicated to Lord Shiva at 11,700 feet."
      },
      {
        name: "Badrinath Temple",
        location: "Chamoli",
        bestSeason: "May to June, September to October",
        description: "Sacred temple dedicated to Lord Vishnu, part of the Char Dham pilgrimage."
      },
      {
        name: "Valley of Flowers",
        location: "Chamoli",
        bestSeason: "July to September",
        description: "UNESCO World Heritage site, alpine valley known for endemic flowers and wildlife."
      },
      {
        name: "Har Ki Pauri",
        location: "Haridwar",
        bestSeason: "October to March",
        description: "Sacred ghat on the Ganges where the evening aarti (prayer) attracts thousands."
      },
      {
        name: "Nainital",
        location: "Nainital",
        bestSeason: "March to June, September to November",
        description: "Popular hill station built around a sacred lake, known for scenic beauty."
      },
      {
        name: "Jim Corbett National Park",
        location: "Nainital",
        bestSeason: "November to June",
        description: "India's first national park, famous for tigers and wildlife conservation."
      },
      {
        name: "Gangotri",
        location: "Uttarkashi",
        bestSeason: "May to June, September to October",
        description: "Source of the Ganges River and important pilgrimage site."
      }
    ],
    culturalHighlights: [
      {
        category: "Spirituality",
        name: "Pilgrimage Heritage",
        description: "Home to Char Dham (four sacred abodes) - Kedarnath, Badrinath, Gangotri, and Yamunotri. The state is considered highly sacred in Hinduism with numerous temples and ashrams."
      },
      {
        category: "Culture",
        name: "Pahari Culture",
        description: "Rich mountain culture with unique traditions, folk music, and dances. The Garhwali and Kumaoni communities have distinct cultural practices and languages."
      },
      {
        category: "Environment",
        name: "Himalayan Ecology",
        description: "Part of the fragile Himalayan ecosystem with diverse flora and fauna. The state is at the forefront of environmental conservation and sustainable tourism practices."
      },
      {
        category: "Food",
        name: "Mountain Cuisine",
        description: "Simple yet nutritious cuisine adapted to mountain climate, featuring dishes like kafuli, bhatt ki churkani, and bal mithai. The cuisine uses local grains and vegetables."
      }
    ]
  },

  "west-bengal": {
    name: "West Bengal",
    image: "/api/placeholder/800/400",
    description: "The cultural capital of India, known for literature, arts, sweets, and intellectual heritage.",
    history: "West Bengal has been a major center of Indian civilization, trade, and culture for over two millennia. The region was ruled by various dynasties including the Mauryas, Guptas, Palas, and Senas. During medieval times, it was part of the Bengal Sultanate and later the Mughal Empire. The British established their first stronghold in Calcutta (now Kolkata), making it the capital of British India until 1911. The state played a crucial role in India's independence movement and cultural renaissance. Bengal was partitioned in 1947, with the western part becoming West Bengal.",
    festivals: [
      {
        name: "Durga Puja",
        significance: "Celebration of goddess Durga's victory over evil",
        description: "Most important festival in West Bengal, celebrating the victory of goddess Durga over demon Mahishasura.",
        celebration: "Elaborate pandals (temporary structures) house artistic sculptures of goddess Durga. Five-day celebration includes cultural programs, traditional music, dance, and community feasts culminating in immersion processions."
      },
      {
        name: "Poila Boishakh",
        significance: "Bengali New Year celebration",
        description: "Traditional new year celebration marking the beginning of the Bengali calendar.",
        celebration: "People wear new clothes, exchange greetings, prepare traditional foods like panta bhat, and participate in cultural programs. Businesses start new ledgers and seek blessings for prosperity."
      },
      {
        name: "Kali Puja",
        significance: "Worship of goddess Kali",
        description: "Night-long festival dedicated to goddess Kali, celebrated with great devotion.",
        celebration: "Elaborate decorations, traditional rituals, cultural performances, and community celebrations. The festival showcases Bengal's rich spiritual traditions."
      }
    ],
    monuments: [
      {
        name: "Victoria Memorial",
        location: "Kolkata",
        bestSeason: "October to March",
        description: "Magnificent marble monument dedicated to Queen Victoria, now a museum showcasing colonial history."
      },
      {
        name: "Howrah Bridge",
        location: "Kolkata",
        bestSeason: "October to March",
        description: "Iconic cantilever bridge over Hooghly River, symbol of Kolkata's engineering heritage."
      },
      {
        name: "Dakshineswar Kali Temple",
        location: "Kolkata",
        bestSeason: "October to March",
        description: "Sacred temple where mystic Ramakrishna Paramahamsa attained spiritual realization."
      },
      {
        name: "Sundarbans",
        location: "South 24 Parganas",
        bestSeason: "September to March",
        description: "UNESCO World Heritage site, largest mangrove forest and home to Royal Bengal Tigers."
      },
      {
        name: "Bishnupur Temples",
        location: "Bankura",
        bestSeason: "October to March",
        description: "Terracotta temples showcasing unique Bengali architecture and craftsmanship."
      },
      {
        name: "Darjeeling Himalayan Railway",
        location: "Darjeeling",
        bestSeason: "March to May, October to December",
        description: "UNESCO World Heritage toy train journey through scenic tea gardens and mountains."
      },
      {
        name: "Belur Math",
        location: "Howrah",
        bestSeason: "October to March",
        description: "Headquarters of Ramakrishna Mission, showcasing architectural synthesis of different religions."
      }
    ],
    culturalHighlights: [
      {
        category: "Literature",
        name: "Bengali Renaissance",
        description: "West Bengal was the center of the Bengali Renaissance with luminaries like Rabindranath Tagore, Bankim Chandra Chattopadhyay, and Swami Vivekananda contributing to literature, philosophy, and social reform."
      },
      {
        category: "Arts",
        name: "Cultural Traditions",
        description: "Rich tradition of classical and folk arts including Rabindra Sangeet, Baul music, classical dance, theater, and film industry (Tollywood). The state has produced numerous artists, musicians, and filmmakers."
      },
      {
        category: "Food",
        name: "Bengali Cuisine",
        description: "Renowned for its sophisticated cuisine featuring fish, rice, and sweets. Famous dishes include machher jhol, kosha mangsho, and sweets like rasgulla, sandesh, and mishti doi."
      },
      {
        category: "Intellectual Heritage",
        name: "Academic Excellence",
        description: "Home to prestigious institutions and a strong tradition of intellectual discourse. The state has produced numerous Nobel laureates, scientists, and scholars who have contributed to various fields."
      }
    ]
  },

  // Union Territories
  "andaman-and-nicobar-islands": {
    name: "Andaman and Nicobar Islands",
    image: "/api/placeholder/800/400",
    description: "Tropical paradise with pristine beaches, coral reefs, and rich marine biodiversity.",
    history: "The Andaman and Nicobar Islands have been inhabited by indigenous tribes for thousands of years. The islands gained historical significance during British rule when they were used as a penal colony for Indian freedom fighters. The Cellular Jail in Port Blair became a symbol of India's struggle for independence. After independence, the islands have developed into a major tourist destination while preserving their natural heritage and respecting indigenous communities.",
    festivals: [
      {
        name: "Island Tourism Festival",
        significance: "Celebration of island culture and tourism",
        description: "Annual festival showcasing the islands' natural beauty, culture, and tourism potential.",
        celebration: "Cultural performances, water sports, local cuisine exhibitions, and eco-tourism activities. The festival promotes sustainable tourism and cultural exchange."
      }
    ],
    monuments: [
      {
        name: "Cellular Jail",
        location: "Port Blair",
        bestSeason: "October to May",
        description: "Historic prison known as 'Kala Pani' where Indian freedom fighters were imprisoned."
      },
      {
        name: "Radhanagar Beach",
        location: "Havelock Island",
        bestSeason: "October to May",
        description: "One of Asia's best beaches known for white sand and crystal-clear waters."
      },
      {
        name: "Ross Island",
        location: "Port Blair",
        bestSeason: "October to May",
        description: "Former British administrative headquarters, now ruins overtaken by nature."
      },
      {
        name: "Mahatma Gandhi Marine National Park",
        location: "Wandoor",
        bestSeason: "October to May",
        description: "Protected marine area with coral reefs and diverse marine life."
      }
    ],
    culturalHighlights: [
      {
        category: "Environment",
        name: "Marine Biodiversity",
        description: "Rich marine ecosystem with coral reefs, diverse fish species, and sea turtles. The islands are crucial for marine conservation in the Indian Ocean."
      },
      {
        category: "Culture",
        name: "Indigenous Heritage",
        description: "Home to several indigenous tribes including the Sentinelese, Jarawas, and Onges who maintain traditional lifestyles and are protected by the government."
      }
    ]
  },

  "chandigarh": {
    name: "Chandigarh",
    image: "/api/placeholder/800/400",
    description: "The planned city designed by Le Corbusier, known for modern architecture and urban planning.",
    history: "Chandigarh was designed and built in the 1950s as the new capital of Punjab after partition. The city was planned by French architect Le Corbusier and is considered a masterpiece of modern urban planning. It serves as the capital of both Punjab and Haryana states and is administered as a Union Territory. The city represents post-independence India's vision of modernity and progress.",
    festivals: [
      {
        name: "Rose Festival",
        significance: "Celebration of the city's famous rose garden",
        description: "Annual festival celebrating the blooming of roses in Zakir Hussain Rose Garden.",
        celebration: "Cultural performances, rose competitions, food stalls, and exhibitions showcasing the city's horticultural heritage."
      }
    ],
    monuments: [
      {
        name: "Rock Garden",
        location: "Chandigarh",
        bestSeason: "October to March",
        description: "Unique sculpture garden created from industrial and urban waste by Nek Chand."
      },
      {
        name: "Capitol Complex",
        location: "Chandigarh",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site showcasing Le Corbusier's architectural vision."
      },
      {
        name: "Sukhna Lake",
        location: "Chandigarh",
        bestSeason: "October to March",
        description: "Artificial lake created by damming the Sukhna Choe, popular for boating and recreation."
      }
    ],
    culturalHighlights: [
      {
        category: "Architecture",
        name: "Modern Urban Planning",
        description: "Exemplar of modern city planning with sectored layout, green spaces, and functional architecture. The city demonstrates successful implementation of Le Corbusier's urban design principles."
      },
      {
        category: "Culture",
        name: "Cosmopolitan Identity",
        description: "Blend of Punjabi and Haryanvi cultures with a modern, cosmopolitan outlook. The city has developed its own unique identity while serving two states."
      }
    ]
  },

  "dadra-and-nagar-haveli-and-daman-and-diu": {
    name: "Dadra and Nagar Haveli and Daman and Diu",
    image: "/api/placeholder/800/400",
    description: "Former Portuguese colonies known for beaches, churches, and Portuguese heritage.",
    history: "These territories were Portuguese colonies until their liberation by India in 1961. Daman and Diu are coastal enclaves known for their beaches and Portuguese architecture, while Dadra and Nagar Haveli is an inland territory with significant tribal population. The areas have retained Portuguese influence in architecture, cuisine, and culture while integrating with India.",
    festivals: [
      {
        name: "Festa de Diu",
        significance: "Cultural festival celebrating local heritage",
        description: "Festival showcasing the region's Portuguese influence and local culture.",
        celebration: "Cultural performances, local cuisine, crafts exhibitions, and traditional music celebrating the unique heritage of the region."
      }
    ],
    monuments: [
      {
        name: "Diu Fort",
        location: "Diu",
        bestSeason: "October to March",
        description: "Portuguese fort overlooking the Arabian Sea with well-preserved architecture."
      },
      {
        name: "St. Paul's Church",
        location: "Diu",
        bestSeason: "October to March",
        description: "Beautiful Portuguese church showcasing baroque architecture."
      },
      {
        name: "Nagoa Beach",
        location: "Diu",
        bestSeason: "October to March",
        description: "Pristine beach known for its golden sand and palm trees."
      }
    ],
    culturalHighlights: [
      {
        category: "Heritage",
        name: "Portuguese Legacy",
        description: "Unique blend of Portuguese and Indian cultures reflected in architecture, cuisine, and traditions. Churches, forts, and colonial buildings showcase this heritage."
      },
      {
        category: "Tourism",
        name: "Beach Culture",
        description: "Popular tourist destination known for beaches, water sports, and relaxed atmosphere. The region offers a different cultural experience within India."
      }
    ]
  },

  "delhi": {
    name: "Delhi",
    image: "/api/placeholder/800/400",
    description: "The capital territory of India, blending ancient history with modern governance and culture.",
    history: "Delhi has been continuously inhabited for over 2,500 years and has served as the capital of various empires. The city has witnessed the rise and fall of numerous dynasties including the Mughals, who left an indelible mark on its architecture and culture. During British rule, New Delhi was built as the imperial capital. After independence, Delhi became the national capital territory, housing the central government and growing into a major metropolitan area.",
    festivals: [
      {
        name: "Dussehra at Red Fort",
        significance: "Grand celebration of good over evil",
        description: "Spectacular Dussehra celebration held at the historic Red Fort grounds.",
        celebration: "Large-scale dramatic performances depicting the Ramayana, culminating in the burning of Ravana's effigy. The event attracts thousands of spectators and showcases Indian cultural traditions."
      },
      {
        name: "Qutub Festival",
        significance: "Cultural festival at historic monument",
        description: "Annual cultural festival held at the Qutub Minar complex showcasing Indian classical arts.",
        celebration: "Performances of Indian classical music and dance by renowned artists against the backdrop of medieval architecture."
      }
    ],
    monuments: [
      {
        name: "Red Fort",
        location: "Old Delhi",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, former Mughal palace and symbol of India's independence."
      },
      {
        name: "Qutub Minar",
        location: "South Delhi",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, tallest brick minaret in the world dating from 12th century."
      },
      {
        name: "India Gate",
        location: "Central Delhi",
        bestSeason: "October to March",
        description: "War memorial dedicated to Indian soldiers, iconic landmark of New Delhi."
      },
      {
        name: "Lotus Temple",
        location: "South Delhi",
        bestSeason: "October to March",
        description: "Bahá'í House of Worship known for its distinctive lotus-shaped architecture."
      },
      {
        name: "Humayun's Tomb",
        location: "Central Delhi",
        bestSeason: "October to March",
        description: "UNESCO World Heritage site, precursor to Taj Mahal's architecture."
      },
      {
        name: "Jama Masjid",
        location: "Old Delhi",
        bestSeason: "October to March",
        description: "One of India's largest mosques built by Mughal emperor Shah Jahan."
      }
    ],
    culturalHighlights: [
      {
        category: "Governance",
        name: "Political Capital",
        description: "Seat of Indian government housing Parliament, Supreme Court, and Rashtrapati Bhavan. The city is the center of political activity and decision-making in India."
      },
      {
        category: "Culture",
        name: "Cosmopolitan Heritage",
        description: "Melting pot of cultures from across India and the world. The city combines historical heritage with modern lifestyle, hosting numerous cultural institutions and events."
      },
      {
        category: "Food",
        name: "Street Food Culture",
        description: "Famous for diverse street food reflecting influences from across India. Areas like Chandni Chowk and Connaught Place offer culinary experiences representing the country's diversity."
      }
    ]
  },

  "jammu-and-kashmir": {
    name: "Jammu and Kashmir",
    image: "/api/placeholder/800/400",
    description: "Paradise on Earth, known for its breathtaking landscapes, Mughal gardens, and rich cultural heritage.",
    history: "Jammu and Kashmir has a complex history shaped by its strategic location between Central Asia and the Indian subcontinent. The region was ruled by various dynasties including the Hindu Shahis, Muslims rulers, Sikhs, and Dogras. The state's accession to India in 1947 has been a subject of political dispute. The region is known for its natural beauty, particularly the Kashmir Valley, and has faced challenges related to insurgency and political unrest. In 2019, the state was reorganized into two union territories: Jammu and Kashmir, and Ladakh.",
    festivals: [
      {
        name: "Tulip Festival",
        significance: "Celebration of spring blooms in Kashmir",
        description: "Annual festival celebrating the blooming of tulips in Asia's largest tulip garden.",
        celebration: "The Indira Gandhi Memorial Tulip Garden comes alive with millions of tulips in various colors. Cultural programs, photography competitions, and local crafts exhibitions are organized."
      },
      {
        name: "Shikara Festival",
        significance: "Celebration of Dal Lake's heritage",
        description: "Festival showcasing the traditional shikara boats and Kashmir's water culture.",
        celebration: "Decorated shikara races, cultural performances, and exhibitions of Kashmiri handicrafts. The festival promotes Kashmir's tourism and cultural heritage."
      }
    ],
    monuments: [
      {
        name: "Dal Lake",
        location: "Srinagar",
        bestSeason: "April to October",
        description: "Iconic lake with houseboats and shikaras, jewel of Kashmir's natural beauty."
      },
      {
        name: "Mughal Gardens",
        location: "Srinagar",
        bestSeason: "April to October",
        description: "Beautiful terraced gardens including Shalimar Bagh, Nishat Bagh, and Chashme Shahi."
      },
      {
        name: "Gulmarg",
        location: "Baramulla",
        bestSeason: "April to June, December to February",
        description: "Hill station known for skiing, gondola rides, and meadows of flowers."
      },
      {
        name: "Pahalgam",
        location: "Anantnag",
        bestSeason: "April to October",
        description: "Valley of shepherds, base for Amarnath pilgrimage and known for scenic beauty."
      },
      {
        name: "Sonamarg",
        location: "Ganderbal",
        bestSeason: "May to October",
        description: "Meadow of gold known for its glaciers and trekking opportunities."
      },
      {
        name: "Vaishno Devi Temple",
        location: "Jammu",
        bestSeason: "March to October",
        description: "Sacred cave temple dedicated to goddess Vaishno Devi, major pilgrimage site."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Kashmiri Heritage",
        description: "Rich cultural heritage with influences from Central Asia, Persia, and India. Known for Sufi traditions, classical music, and poetry. The region has a syncretic culture with Hindu and Islamic influences."
      },
      {
        category: "Handicrafts",
        name: "Traditional Crafts",
        description: "World-renowned for handicrafts including Pashmina shawls, carpets, papier-mâché items, and walnut wood carvings. These crafts represent centuries-old traditions and exceptional artisanship."
      },
      {
        category: "Food",
        name: "Kashmiri Cuisine",
        description: "Distinctive cuisine influenced by Central Asian and Persian flavors. Famous dishes include Rogan Josh, Yakhni, Kahwa tea, and the elaborate Wazwan feast featuring multiple courses."
      }
    ]
  },

  "ladakh": {
    name: "Ladakh",
    image: "/api/placeholder/800/400",
    description: "The land of high passes, known for its Buddhist monasteries, stark landscapes, and unique culture.",
    history: "Ladakh, meaning 'land of high passes,' has been culturally and historically connected to Tibet. The region was an independent kingdom until the 19th century when it came under the influence of Kashmir and later became part of Jammu and Kashmir. Ladakh has maintained its distinct Buddhist culture and traditions despite various political changes. In 2019, it became a separate union territory, allowing for better preservation of its unique identity and culture.",
    festivals: [
      {
        name: "Hemis Festival",
        significance: "Celebration at Hemis Monastery",
        description: "Most famous festival in Ladakh, celebrating the birth anniversary of Guru Padmasambhava.",
        celebration: "Masked dances (Cham) performed by monks, display of traditional thangka paintings, and cultural activities. The festival attracts visitors from around the world."
      },
      {
        name: "Ladakh Festival",
        significance: "Cultural celebration of Ladakhi heritage",
        description: "Annual festival showcasing Ladakhi culture, traditions, and arts.",
        celebration: "Traditional dances, music performances, archery competitions, polo matches, and exhibitions of local handicrafts and cuisine."
      }
    ],
    monuments: [
      {
        name: "Leh Palace",
        location: "Leh",
        bestSeason: "May to September",
        description: "Former royal palace overlooking Leh town, showcasing Tibetan architecture."
      },
      {
        name: "Hemis Monastery",
        location: "Leh",
        bestSeason: "May to September",
        description: "Largest and richest monastery in Ladakh, famous for its festival and thangka paintings."
      },
      {
        name: "Pangong Tso Lake",
        location: "Changthang",
        bestSeason: "May to September",
        description: "High-altitude lake extending from India to China, known for changing colors."
      },
      {
        name: "Nubra Valley",
        location: "Nubra",
        bestSeason: "June to September",
        description: "High-altitude desert valley known for Bactrian camels and sand dunes."
      },
      {
        name: "Thiksey Monastery",
        location: "Leh",
        bestSeason: "May to September",
        description: "Beautiful monastery resembling Potala Palace, housing a large Buddha statue."
      },
      {
        name: "Magnetic Hill",
        location: "Leh",
        bestSeason: "May to September",
        description: "Mysterious hill where vehicles appear to move uphill due to optical illusion."
      }
    ],
    culturalHighlights: [
      {
        category: "Culture",
        name: "Buddhist Heritage",
        description: "Predominantly Buddhist region with numerous monasteries, gompas, and stupas. The culture is closely related to Tibetan Buddhism with unique local adaptations."
      },
      {
        category: "Environment",
        name: "High-Altitude Ecosystem",
        description: "Unique high-altitude desert ecosystem adapted to extreme conditions. The region faces challenges from climate change and requires sustainable development approaches."
      },
      {
        category: "Traditions",
        name: "Traditional Lifestyle",
        description: "Communities maintain traditional lifestyles adapted to harsh mountain conditions, including unique agricultural practices, animal husbandry, and seasonal migration patterns."
      }
    ]
  },

  "lakshadweep": {
    name: "Lakshadweep",
    image: "/api/placeholder/800/400",
    description: "Coral islands paradise, known for pristine beaches, lagoons, and marine biodiversity.",
    history: "Lakshadweep, meaning 'hundred thousand islands,' consists of 36 coral islands in the Arabian Sea. The islands have been inhabited for over 1,500 years, with early settlers believed to be from Kerala and Karnataka coasts. The region came under various rulers including the Ali Rajas of Kannur and later the British. The islands have maintained their distinct culture with strong Islamic influence and maritime traditions. They became a union territory after independence.",
    festivals: [
      {
        name: "Id-ul-Fitr",
        significance: "Islamic festival marking end of Ramadan",
        description: "Major festival celebrated across the islands with great enthusiasm.",
        celebration: "Community prayers, traditional feasts, cultural programs, and social gatherings. The festival strengthens community bonds across the islands."
      }
    ],
    monuments: [
      {
        name: "Bangaram Island",
        location: "Bangaram",
        bestSeason: "October to May",
        description: "Uninhabited coral island known for pristine beaches and water sports."
      },
      {
        name: "Kavaratti Island",
        location: "Kavaratti",
        bestSeason: "October to May",
        description: "Administrative capital with beautiful lagoons and marine aquarium."
      },
      {
        name: "Agatti Island",
        location: "Agatti",
        bestSeason: "October to May",
        description: "Only airport island, gateway to Lakshadweep with excellent diving spots."
      }
    ],
    culturalHighlights: [
      {
        category: "Environment",
        name: "Marine Conservation",
        description: "Critical marine ecosystem with coral reefs requiring protection from climate change and human activities. The islands are at the forefront of marine conservation efforts."
      },
      {
        category: "Culture",
        name: "Island Culture",
        description: "Unique island culture with strong maritime traditions, coconut-based economy, and sustainable living practices adapted to coral island environment."
      }
    ]
  },

  "puducherry": {
    name: "Puducherry",
    image: "/api/placeholder/800/400",
    description: "Former French colony known for its colonial architecture, spiritual centers, and unique cultural blend.",
    history: "Puducherry was a French colonial settlement from 1674 until 1954, giving it a distinct French character that persists today. The territory consists of four enclaves: Puducherry, Karaikal, Mahe, and Yanam. French influence is evident in architecture, cuisine, and culture. The region has also become known for the Auroville international community and Sri Aurobindo Ashram, making it a significant spiritual center.",
    festivals: [
      {
        name: "Bastille Day",
        significance: "French national day celebration",
        description: "Celebration of French heritage and the French Revolution anniversary.",
        celebration: "Cultural programs, French cuisine festivals, and exhibitions showcasing the Franco-Tamil heritage of the region."
      },
      {
        name: "Pongal",
        significance: "Tamil harvest festival",
        description: "Traditional Tamil festival celebrated alongside other Tamil regions.",
        celebration: "Traditional kolam designs, special foods, and cultural activities reflecting the Tamil heritage of the territory."
      }
    ],
    monuments: [
      {
        name: "Auroville",
        location: "Puducherry",
        bestSeason: "October to March",
        description: "International experimental township promoting human unity and sustainable living."
      },
      {
        name: "Sri Aurobindo Ashram",
        location: "Puducherry",
        bestSeason: "October to March",
        description: "Spiritual ashram founded by Sri Aurobindo, center for integral yoga."
      },
      {
        name: "French Quarter",
        location: "Puducherry",
        bestSeason: "October to March",
        description: "Colonial area with French architecture, cafes, and boutiques."
      },
      {
        name: "Paradise Beach",
        location: "Puducherry",
        bestSeason: "October to March",
        description: "Pristine beach accessible by boat, perfect for relaxation and water sports."
      }
    ],
    culturalHighlights: [
      {
        category: "Heritage",
        name: "Franco-Tamil Culture",
        description: "Unique blend of French colonial and Tamil cultures reflected in architecture, cuisine, and lifestyle. The territory maintains this distinctive character as part of its identity."
      },
      {
        category: "Spirituality",
        name: "Spiritual Centers",
        description: "Important spiritual destination with Sri Aurobindo Ashram and Auroville attracting seekers from around the world. These centers promote integral yoga and human unity."
      }
    ]
  }
};

export const getStateBySlug = (slug: string): StateData | null => {
  return allStatesData[slug] || null;
};

export const getAllStates = (): StateData[] => {
  return Object.values(allStatesData);
};