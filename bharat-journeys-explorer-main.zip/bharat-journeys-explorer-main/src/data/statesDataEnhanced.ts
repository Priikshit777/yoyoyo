export interface Monument {
  name: string;
  location: string;
  bestSeason: string;
  description: string;
  image?: string;
}

export interface Festival {
  name: string;
  significance: string;
  description: string;
  celebration: string;
}

export interface CulturalHighlight {
  category: string;
  name: string;
  description: string;
}

export interface StateData {
  name: string;
  image: string;
  history: string;
  festivals: Festival[];
  monuments: Monument[];
  culturalHighlights: CulturalHighlight[];
  description: string;
}

import { allStatesData, getStateBySlug as getStateBySlugFromAll } from './allStatesData';

export const statesData = allStatesData;

// Helper function to get state data by URL slug
export const getStateBySlug = getStateBySlugFromAll;

// Get all state names for listing
export const getAllStates = (): string[] => {
  return Object.keys(statesData);
};