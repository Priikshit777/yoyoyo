import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home, Map, Info } from 'lucide-react';

const Header = () => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2">
          <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            भारत दर्पण
          </span>
        </Link>

        {/* Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          <Button
            variant={isActive('/') ? 'heritage' : 'ghost'}
            asChild
            size="sm"
            className="gap-2"
          >
            <Link to="/">
              <Home className="w-4 h-4" />
              Interactive Map
            </Link>
          </Button>
          
          <Button
            variant={isActive('/states') ? 'heritage' : 'ghost'}
            asChild
            size="sm"
            className="gap-2"
          >
            <Link to="/states">
              <Map className="w-4 h-4" />
              Explore States
            </Link>
          </Button>

          <Button
            variant={isActive('/about') ? 'heritage' : 'ghost'}
            asChild
            size="sm"
            className="gap-2"
          >
            <Link to="/about">
              <Info className="w-4 h-4" />
              About
            </Link>
          </Button>

        </nav>

        {/* Mobile Menu Button */}
        <Button variant="ghost" size="sm" className="md:hidden">
          <Map className="w-5 h-5" />
        </Button>
      </div>
    </header>
  );
};

export default Header;