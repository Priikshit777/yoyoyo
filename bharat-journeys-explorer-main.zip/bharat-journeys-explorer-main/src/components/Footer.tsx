import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="border-t border-border/40 bg-card/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              भारत दर्पण
            </h3>
            <p className="text-muted-foreground text-sm">
              Exploring India's rich heritage, vibrant culture, and timeless traditions through an interactive digital experience.
            </p>
          </div>

          {/* Navigation */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">Explore</h4>
            <div className="flex flex-col space-y-2 text-sm">
              <Link to="/" className="text-muted-foreground hover:text-primary smooth-transition">
                Interactive Map
              </Link>
              <Link to="/states" className="text-muted-foreground hover:text-primary smooth-transition">
                All States
              </Link>
              <Link to="/about" className="text-muted-foreground hover:text-primary smooth-transition">
                About Heritage
              </Link>
            </div>
          </div>

          {/* Cultural Info */}
          <div className="space-y-4">
            <h4 className="font-semibold text-foreground">Cultural Heritage</h4>
            <div className="text-sm text-muted-foreground space-y-1">
              <p>🏛️ Ancient Monuments</p>
              <p>🎭 Traditional Arts</p>
              <p>🎪 Vibrant Festivals</p>
              <p>🍛 Rich Cuisine</p>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-border/20 text-center">
          <p className="text-sm text-muted-foreground">
            © 2025 Bharat Darpan — A Digital Odyssey through India's Heritage
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;