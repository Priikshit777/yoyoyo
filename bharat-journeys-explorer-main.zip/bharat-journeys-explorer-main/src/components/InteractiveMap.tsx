import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { motion } from 'framer-motion';

const InteractiveMap = () => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const navigate = useNavigate();
  const [hoveredState, setHoveredState] = useState<string>('');

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Initialize the map
    const map = L.map(mapRef.current, {
      crs: L.CRS.Simple,
      zoomControl: true,
      attributionControl: false,
    }).setView([22.5937, 82.9629], 5);

    mapInstanceRef.current = map;

    // Define styles
    const defaultStyle = {
      fillColor: 'rgba(192, 132, 252, 0.6)', // Purple
      weight: 2,
      opacity: 1,
      color: 'rgba(236, 72, 153, 0.9)', // Pink border
      fillOpacity: 0.7
    };

    const hoverStyle = {
      weight: 3,
      color: '#FFFFFF',
      fillColor: 'rgba(236, 72, 153, 0.8)',
      fillOpacity: 0.9
    };

    // Load and display GeoJSON data
    fetch('/data/in.json')
      .then(response => response.json())
      .then(data => {
        const geojsonLayer = L.geoJSON(data, {
          style: defaultStyle,
          onEachFeature: (feature, layer) => {
            const stateName = feature.properties.NAME_1 || feature.properties.name || 'Unknown';
            
            layer.on({
              mouseover: (e) => {
                const targetLayer = e.target;
                targetLayer.setStyle(hoverStyle);
                targetLayer.bringToFront();
                setHoveredState(stateName);
              },
              mouseout: (e) => {
                const targetLayer = e.target;
                targetLayer.setStyle(defaultStyle);
                setHoveredState('');
              },
              click: () => {
                navigate(`/state/${stateName.toLowerCase().replace(/\s+/g, '-')}`);
              }
            });

            // Add tooltip
            layer.bindTooltip(stateName, {
              permanent: false,
              direction: 'center',
              className: 'state-tooltip'
            });
          }
        });

        geojsonLayer.addTo(map);
        map.fitBounds(geojsonLayer.getBounds());
      })
      .catch(error => {
        console.error('Error loading map data:', error);
      });

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [navigate]);

  return (
    <div className="relative w-full h-full">
      <div 
        ref={mapRef} 
        className="w-full h-[600px] md:h-[700px] rounded-2xl border border-border/40 heritage-shadow overflow-hidden"
      />
      
      {/* Hover State Display */}
      {hoveredState && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="absolute bottom-4 left-4 bg-card/90 backdrop-blur-sm border border-border/40 rounded-lg px-4 py-2"
        >
          <p className="text-sm font-medium text-foreground">
            {hoveredState}
          </p>
          <p className="text-xs text-muted-foreground">
            Click to explore
          </p>
        </motion.div>
      )}

      {/* Map Instructions */}
      <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm border border-border/40 rounded-lg px-4 py-3 max-w-xs">
        <h4 className="text-sm font-semibold text-foreground mb-2">How to Explore</h4>
        <div className="text-xs text-muted-foreground space-y-1">
          <p>🖱️ Hover over any state to highlight</p>
          <p>👆 Click on a state to explore its heritage</p>
          <p>🔍 Use zoom controls to get a closer look</p>
        </div>
      </div>

      <style>{`
        .state-tooltip {
          background: hsl(var(--card)) !important;
          border: 1px solid hsl(var(--border)) !important;
          border-radius: 8px !important;
          color: hsl(var(--foreground)) !important;
          font-weight: 600 !important;
          padding: 8px 12px !important;
          box-shadow: var(--shadow-glow) !important;
        }
        
        .state-tooltip::before {
          border-top-color: hsl(var(--card)) !important;
        }
      `}</style>
    </div>
  );
};

export default InteractiveMap;