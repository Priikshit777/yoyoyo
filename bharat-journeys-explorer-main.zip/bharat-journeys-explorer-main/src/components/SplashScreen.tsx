import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen = ({ onComplete }: SplashScreenProps) => {
  const [showSplash, setShowSplash] = useState(true);

  const handleClick = () => {
    setShowSplash(false);
    onComplete();
  };

  return (
    <AnimatePresence>
      {showSplash && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          onClick={handleClick}
          className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-background via-secondary/20 to-background overflow-hidden cursor-pointer"
        >
          {/* Animated Background Elements */}
          <div className="absolute inset-0">
            <div className="absolute top-20 left-20 w-32 h-32 bg-primary/20 rounded-full blur-xl animate-pulse"></div>
            <div className="absolute bottom-20 right-20 w-48 h-48 bg-accent/20 rounded-full blur-xl animate-pulse delay-1000"></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-secondary/10 rounded-full blur-2xl animate-pulse delay-500"></div>
          </div>

          <div className="relative z-10 text-center px-8 max-w-2xl">
            {/* Main Logo/Title */}
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
              className="mb-8"
            >
              <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent mb-4">
                भारत दर्पण
              </h1>
              <p className="text-2xl md:text-3xl font-light text-foreground/90">
                Bharat Darpan
              </p>
            </motion.div>

            {/* Cultural Elements */}
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 1, duration: 0.8 }}
              className="mb-8 text-6xl"
            >
              🇮🇳
            </motion.div>

            {/* Welcome Message */}
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1.5, duration: 0.8 }}
              className="mb-8"
            >
              <p className="text-xl md:text-2xl text-foreground/80 mb-4">
                Get ready to witness the beauty of India
              </p>
              <p className="text-lg text-muted-foreground">
                Embark on a journey through India's rich heritage, vibrant culture, and timeless traditions
              </p>
            </motion.div>

            {/* Skip Button */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 2, duration: 0.6 }}
            >
              <p className="text-muted-foreground text-sm mb-4">
                Click anywhere to continue
              </p>
              <Button
                variant="heritage"
                size="lg"
                onClick={handleClick}
                className="text-lg px-8 py-3"
              >
                Begin Your Journey
              </Button>
            </motion.div>

          </div>

          {/* Decorative Elements */}
          <div className="absolute top-8 left-8 text-4xl animate-bounce delay-300">✨</div>
          <div className="absolute top-16 right-12 text-3xl animate-bounce delay-700">🕉️</div>
          <div className="absolute bottom-16 left-16 text-3xl animate-bounce delay-1000">🏛️</div>
          <div className="absolute bottom-8 right-8 text-4xl animate-bounce delay-1300">🎨</div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default SplashScreen;