import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MapPin, Calendar, Star, Camera } from 'lucide-react';
import { getStateBySlug } from '@/data/statesDataEnhanced';

const StateDetailPage = () => {
  const { stateName } = useParams<{ stateName: string }>();
  const navigate = useNavigate();

  if (!stateName) {
    return <div>State not found</div>;
  }

  const stateData = getStateBySlug(stateName);

  if (!stateData) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">State Not Found</h1>
        <p className="text-muted-foreground mb-6">The state you're looking for doesn't exist in our database.</p>
        <Button onClick={() => navigate('/')} variant="heritage">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Map
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="relative h-96 bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
        <div className="container mx-auto px-4 h-full flex items-end pb-8 relative z-10">
          <div className="space-y-4">
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <Button 
                variant="ghost" 
                onClick={() => navigate('/')}
                className="mb-4 text-foreground/80 hover:text-foreground"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Map
              </Button>
            </motion.div>
            
            <motion.h1 
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"
            >
              {stateData.name}
            </motion.h1>
            
            <motion.p 
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="text-xl text-foreground/80 max-w-2xl"
            >
              {stateData.description}
            </motion.p>
          </div>
        </div>
      </motion.div>

      <div className="container mx-auto px-4 py-12 space-y-16">
        {/* History Section */}
        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          <Card className="heritage-shadow">
            <CardHeader>
              <CardTitle className="text-3xl text-center bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Rich Historical Heritage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg leading-relaxed text-foreground/90">
                {stateData.history}
              </p>
            </CardContent>
          </Card>
        </motion.section>

        {/* Festivals Section */}
        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
            Vibrant Festivals
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stateData.festivals.map((festival, index) => (
              <motion.div
                key={festival.name}
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.8 + index * 0.1, duration: 0.6 }}
              >
                <Card className="h-full heritage-shadow hover:scale-105 smooth-transition">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Star className="w-5 h-5 text-accent" />
                      {festival.name}
                    </CardTitle>
                    <Badge variant="secondary" className="w-fit">
                      {festival.significance}
                    </Badge>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-foreground/80">{festival.description}</p>
                    <div className="bg-muted/50 rounded-lg p-3">
                      <p className="text-sm text-foreground/70">
                        <strong>How it's celebrated:</strong> {festival.celebration}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Monuments Section */}
        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">
            Historic Monuments
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {stateData.monuments.map((monument, index) => (
              <motion.div
                key={monument.name}
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1 + index * 0.1, duration: 0.6 }}
              >
                <Card className="h-full heritage-shadow hover:scale-105 smooth-transition">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Camera className="w-5 h-5 text-primary" />
                      {monument.name}
                    </CardTitle>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {monument.location}
                      </Badge>
                      <Badge variant="cultural" className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {monument.bestSeason}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground/80">{monument.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Cultural Highlights Section */}
        <motion.section
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.1, duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Cultural Treasures
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {stateData.culturalHighlights.map((highlight, index) => (
              <motion.div
                key={highlight.name}
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1.2 + index * 0.1, duration: 0.6 }}
              >
                <Card className="heritage-shadow hover:scale-105 smooth-transition">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>{highlight.name}</CardTitle>
                      <Badge variant="mystic">{highlight.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground/80">{highlight.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Back to Map CTA */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.3, duration: 0.6 }}
          className="text-center pt-8"
        >
          <Button 
            variant="heritage" 
            size="lg"
            onClick={() => navigate('/')}
            className="gap-2"
          >
            <ArrowLeft className="w-5 h-5" />
            Explore More States on the Map
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

export default StateDetailPage;